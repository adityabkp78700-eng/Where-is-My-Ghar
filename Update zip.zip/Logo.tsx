interface LogoProps {
  size?: number;
  className?: string;
}

export default function Logo({ size = 40, className = '' }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 512 512"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Where Is My Ghar logo"
    >
      <defs>
        <linearGradient id="wimg-bg-grad" x1="0" y1="0" x2="512" y2="512" gradientUnits="userSpaceOnUse">
          <stop stopColor="#1E40AF" />
          <stop offset="1" stopColor="#047857" />
        </linearGradient>
        <linearGradient id="wimg-house-grad" x1="180" y1="160" x2="332" y2="310" gradientUnits="userSpaceOnUse">
          <stop stopColor="#1E40AF" />
          <stop offset="1" stopColor="#047857" />
        </linearGradient>
      </defs>
      {/* Background Rounded Canvas */}
      <rect width="512" height="512" rx="120" fill="url(#wimg-bg-grad)" />
      {/* Location Pin Main Body */}
      <path
        d="M256 90C177.58 90 114 153.58 114 232C114 328 256 422 256 422C256 422 398 328 398 232C398 153.58 334.42 90 256 90Z"
        fill="white"
      />
      {/* Inner House Shape */}
      <path
        d="M256 160L180 226V300C180 305.523 184.477 310 190 310H230V250H282V310H322C327.523 310 332 305.523 332 300V226L256 160Z"
        fill="url(#wimg-house-grad)"
      />
    </svg>
  );
}
