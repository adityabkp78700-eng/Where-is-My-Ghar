import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';
import type { Property, SearchAlert } from '@/lib/types';

const SAVED_KEY = 'wimg:saved';
const RECENT_KEY = 'wimg:recent';
const ALERTS_KEY = 'wimg:search-alerts';
const MAX_SAVED = 20;
const MAX_RECENT = 8;
const MAX_ALERTS = 5;

interface SavedContextValue {
  savedProperties: Property[];
  recentlyViewed: Property[];
  searchAlerts: SearchAlert[];
  isSaved: (id: string) => boolean;
  toggleSave: (p: Property) => void;
  addRecentlyViewed: (p: Property) => void;
  addSearchAlert: (alert: Omit<SearchAlert, 'id' | 'created_at'>) => void;
  removeSearchAlert: (id: string) => void;
}

const SavedContext = createContext<SavedContextValue | null>(null);

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function SavedProvider({ children }: { children: ReactNode }) {
  const [savedProperties, setSavedProperties] = useState<Property[]>(() => loadFromStorage(SAVED_KEY, []));
  const [recentlyViewed, setRecentlyViewed] = useState<Property[]>(() => loadFromStorage(RECENT_KEY, []));
  const [searchAlerts, setSearchAlerts] = useState<SearchAlert[]>(() => loadFromStorage(ALERTS_KEY, []));

  useEffect(() => {
    localStorage.setItem(SAVED_KEY, JSON.stringify(savedProperties));
  }, [savedProperties]);

  useEffect(() => {
    localStorage.setItem(RECENT_KEY, JSON.stringify(recentlyViewed));
  }, [recentlyViewed]);

  useEffect(() => {
    localStorage.setItem(ALERTS_KEY, JSON.stringify(searchAlerts));
  }, [searchAlerts]);

  const isSaved = useCallback((id: string) => savedProperties.some((p) => p.id === id), [savedProperties]);

  const toggleSave = useCallback((p: Property) => {
    setSavedProperties((prev) => {
      if (prev.some((item) => item.id === p.id)) {
        return prev.filter((item) => item.id !== p.id);
      }
      return [p, ...prev].slice(0, MAX_SAVED);
    });
  }, []);

  const addRecentlyViewed = useCallback((p: Property) => {
    setRecentlyViewed((prev) => {
      const filtered = prev.filter((item) => item.id !== p.id);
      return [p, ...filtered].slice(0, MAX_RECENT);
    });
  }, []);

  const addSearchAlert = useCallback((alert: Omit<SearchAlert, 'id' | 'created_at'>) => {
    setSearchAlerts((prev) => {
      const dupe = prev.some(
        (a) => a.city.toLowerCase() === alert.city.toLowerCase() && a.budget === alert.budget && a.category === alert.category
      );
      if (dupe) return prev;
      const newAlert: SearchAlert = {
        ...alert,
        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        created_at: new Date().toISOString(),
      };
      return [newAlert, ...prev].slice(0, MAX_ALERTS);
    });
  }, []);

  const removeSearchAlert = useCallback((id: string) => {
    setSearchAlerts((prev) => prev.filter((a) => a.id !== id));
  }, []);

  return (
    <SavedContext.Provider
      value={{ savedProperties, recentlyViewed, searchAlerts, isSaved, toggleSave, addRecentlyViewed, addSearchAlert, removeSearchAlert }}
    >
      {children}
    </SavedContext.Provider>
  );
}

export function useSaved() {
  const ctx = useContext(SavedContext);
  if (!ctx) throw new Error('useSaved must be used within SavedProvider');
  return ctx;
}
