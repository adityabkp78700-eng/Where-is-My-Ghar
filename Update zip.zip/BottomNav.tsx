import { Search, Building2 } from 'lucide-react';
import type { AppMode } from '@/lib/types';

interface BottomNavProps {
  mode: AppMode;
  onModeChange: (m: AppMode) => void;
}

export default function BottomNav({ mode, onModeChange }: BottomNavProps) {
  const tabs = [
    { id: 'guest' as AppMode, label: 'Guest · Find', icon: Search },
    { id: 'owner' as AppMode, label: 'Owner · List', icon: Building2 },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 px-4 pb-2 gpu-layer">
      <div className="mx-auto flex h-[66px] max-w-2xl items-center gap-2 rounded-[34px] border border-slate-200/80 bg-white/95 p-2 shadow-[0_10px_35px_rgba(15,23,42,0.14)] backdrop-blur-xl dark:border-slate-700 dark:bg-slate-900/95">
        {tabs.map((tab) => {
          const active = mode === tab.id;
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => onModeChange(tab.id)}
              className={`flex h-full flex-1 items-center justify-center gap-3 rounded-[28px] px-3 text-[15px] font-semibold tracking-[-0.5px] btn-press nav-pill ${
                active
                  ? 'bg-[#e7f0ff] text-[#1470d0] shadow-[0_10px_25px_rgba(44,108,200,0.12)] dark:bg-teal-900/30 dark:text-teal-300'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="h-5 w-5" strokeWidth={2.2} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
