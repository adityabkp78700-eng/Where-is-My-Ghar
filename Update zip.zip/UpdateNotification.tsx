import { useState, useEffect } from 'react';
import { RefreshCw, X } from 'lucide-react';

export default function UpdateNotification() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const checkUpdate = () => {
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready.then((reg) => {
          reg.addEventListener('controllerchange', () => {
            setShow(true);
          });
        });
      }
    };

    // Also check for version mismatch on load
    const lastVersion = localStorage.getItem('wimg-version');
    const currentVersion = '1.0.0';
    if (lastVersion && lastVersion !== currentVersion) {
      setShow(true);
      localStorage.setItem('wimg-version', currentVersion);
    } else if (!lastVersion) {
      localStorage.setItem('wimg-version', currentVersion);
    }

    checkUpdate();
  }, []);

  const handleUpdate = () => {
    window.location.reload();
  };

  if (!show) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 z-50 max-w-2xl mx-auto">
      <div className="bg-teal-600 rounded-2xl shadow-xl p-3 flex items-center gap-3 sheet-enter">
        <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
          <RefreshCw className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-white">A new update is available!</p>
          <p className="text-xs text-teal-100">Get the latest features and improvements</p>
        </div>
        <button
          onClick={handleUpdate}
          className="px-4 py-1.5 rounded-lg bg-white text-teal-600 text-xs font-bold btn-press flex-shrink-0"
        >
          Update Now
        </button>
        <button onClick={() => setShow(false)} className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
          <X className="w-3.5 h-3.5 text-white" />
        </button>
      </div>
    </div>
  );
}
