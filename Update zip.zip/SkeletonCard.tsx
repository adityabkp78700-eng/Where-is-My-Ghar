export default function SkeletonCard() {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700">
      <div className="h-44 shimmer" />
      <div className="p-3 space-y-2.5">
        <div className="flex gap-2">
          <div className="h-5 w-16 rounded-full shimmer" />
          <div className="h-5 w-20 rounded-full shimmer" />
        </div>
        <div className="h-4 w-3/4 rounded shimmer" />
        <div className="h-3 w-1/2 rounded shimmer" />
        <div className="flex gap-2 pt-1">
          <div className="h-7 w-16 rounded-lg shimmer" />
          <div className="h-7 w-16 rounded-lg shimmer" />
          <div className="h-7 w-16 rounded-lg" />
        </div>
      </div>
    </div>
  );
}
