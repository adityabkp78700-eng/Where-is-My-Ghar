import { useState, useEffect, useCallback, useRef } from 'react';
import { ThemeProvider } from '@/context/ThemeContext';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { ToastProvider, useToast } from '@/context/ToastContext';
import { SavedProvider, useSaved } from '@/context/SavedContext';
import Splash from '@/components/Splash';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import BottomNav from '@/components/BottomNav';
import GuestView from '@/views/GuestView';
import OwnerDashboard from '@/views/OwnerDashboard';
import PropertyDetailModal from '@/components/PropertyDetailModal';
import AuthModal from '@/components/AuthModal';
import ListingFormModal from '@/components/ListingFormModal';
import ReportModal from '@/components/ReportModal';
import PWAInstallBanner from '@/components/PWAInstallBanner';
import UpdateNotification from '@/components/UpdateNotification';
import Confetti from '@/components/Confetti';
import PhotoLightbox from '@/components/PhotoLightbox';
import { supabase } from '@/lib/supabase';
import type { AppMode, Property } from '@/lib/types';

function AppContent() {
  const { user } = useAuth();
  const { showToast } = useToast();

  const [showSplash, setShowSplash] = useState(true);
  const [mode, setMode] = useState<AppMode>('guest');
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [reportProperty, setReportProperty] = useState<Property | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authAction, setAuthAction] = useState<string | null>(null);
  const [listingFormOpen, setListingFormOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  const [ownerRefreshKey, setOwnerRefreshKey] = useState(0);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const [guestResetKey, setGuestResetKey] = useState(0);
  const [lightbox, setLightbox] = useState<{ photos: string[]; index: number } | null>(null);
  const { addRecentlyViewed } = useSaved();

  // Splash timer
  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  // Deep-link handling: /property/:id
  useEffect(() => {
    const checkDeepLink = async () => {
      const path = window.location.pathname;
      const match = path.match(/^\/property\/([\w-]+)/);
      if (match) {
        const propertyId = match[1];
        const { data, error } = await supabase
          .from('properties')
          .select('*')
          .eq('id', propertyId)
          .maybeSingle();
        if (data && !error) {
          addRecentlyViewed(data);
          setSelectedProperty(data);
        }
      }
    };
    if (!showSplash) checkDeepLink();
  }, [showSplash, addRecentlyViewed]);

  const handleModeChange = (m: AppMode) => {
    if (m === mode) return;
    setMode(m);
    showToast(m === 'owner' ? 'Switched to Owner Dashboard' : 'Switched to Guest Browsing', 'info');
  };

  const requireAuth = (action: string, callback: () => void) => {
    if (user) {
      callback();
    } else {
      setAuthAction(action);
      setPendingAction(() => callback);
      setAuthModalOpen(true);
    }
  };

  const handleCallOwner = useCallback((p: Property) => {
    requireAuth('Call Owner', () => {
      window.location.href = `tel:+91${p.owner_phone}`;
    });
  }, [user]);

  const handleWhatsAppOwner = useCallback((p: Property) => {
    requireAuth('WhatsApp Owner', () => {
      const msg = encodeURIComponent(`Hi, I found your ${p.category} listing on Where Is My Ghar. Is it still available?`);
      window.open(`https://wa.me/91${p.owner_phone}?text=${msg}`, '_blank');
    });
  }, [user]);

  const handleAddNew = () => {
    requireAuth('List Your Property', () => {
      setEditingProperty(null);
      setListingFormOpen(true);
    });
  };

  const handleEdit = (p: Property) => {
    setEditingProperty(p);
    setListingFormOpen(true);
  };

  const handleOpenDetail = useCallback((p: Property) => {
    addRecentlyViewed(p);
    setSelectedProperty(p);
  }, [addRecentlyViewed]);

  const handleOpenPhoto = useCallback((photos: string[], index: number) => {
    if (photos.length > 0) setLightbox({ photos, index });
  }, []);

  const handleRented = () => {
    setShowConfetti(true);
    setOwnerRefreshKey((k) => k + 1);
  };

  const handleAuthSuccess = () => {
    setAuthModalOpen(false);
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  };

  const handleSignInFromHeader = () => {
    setAuthAction(null);
    setAuthModalOpen(true);
  };

  const handleLogoClick = () => {
    if (mode === 'owner') {
      setOwnerRefreshKey((k) => k + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      showToast('🔑 Dashboard Refreshed', 'info');
    } else {
      setGuestResetKey((k) => k + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      showToast('🔍 Search Reset', 'success');
    }
  };

  if (showSplash) return <Splash />;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950">
      <Header mode={mode} onSignIn={handleSignInFromHeader} onLogoClick={handleLogoClick} />

      <main key={mode} className={`mode-view-enter flex-1 max-w-2xl mx-auto w-full px-4 pt-3 pb-28 gpu-scroll ${mode === 'guest' ? 'bg-[#f4f9fd] dark:bg-slate-950' : 'bg-slate-50 dark:bg-slate-950'}`}>
        {mode === 'guest' ? (
          <GuestView
              key={guestResetKey}
              onOpenDetail={handleOpenDetail}
              onOpenPhoto={handleOpenPhoto}
              onCallOwner={handleCallOwner}
              onWhatsAppOwner={handleWhatsAppOwner}
              onReport={setReportProperty}
            />
        ) : (
          <OwnerDashboard
            onEdit={handleEdit}
            onAddNew={handleAddNew}
            refreshKey={ownerRefreshKey}
            onRented={handleRented}
          />
        )}
      </main>

      <Footer />
      <BottomNav mode={mode} onModeChange={handleModeChange} />

      <PropertyDetailModal
        property={selectedProperty}
        onClose={() => setSelectedProperty(null)}
        onOpenPhoto={handleOpenPhoto}
        onCallOwner={handleCallOwner}
        onWhatsAppOwner={handleWhatsAppOwner}
        onReport={(p) => {
          setSelectedProperty(null);
          setReportProperty(p);
        }}
      />

      <ReportModal
        property={reportProperty}
        onClose={() => setReportProperty(null)}
      />

      <AuthModal
        open={authModalOpen}
        onClose={() => {
          setAuthModalOpen(false);
          setPendingAction(null);
        }}
        onSuccess={handleAuthSuccess}
        title={authAction ? `Sign in to ${authAction}` : undefined}
      />

      <ListingFormModal
        open={listingFormOpen}
        onClose={() => setListingFormOpen(false)}
        onSaved={() => {
          setListingFormOpen(false);
          setOwnerRefreshKey((k) => k + 1);
        }}
        editingProperty={editingProperty}
      />

      <PWAInstallBanner />
      <UpdateNotification />
      {lightbox && (
        <PhotoLightbox
          photos={lightbox.photos}
          initialIndex={lightbox.index}
          onClose={() => setLightbox(null)}
        />
      )}
      {showConfetti && <Confetti onDone={() => setShowConfetti(false)} />}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <SavedProvider>
          <ToastProvider>
            <AppContent />
          </ToastProvider>
        </SavedProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
