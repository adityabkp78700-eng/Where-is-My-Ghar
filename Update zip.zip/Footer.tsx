export default function Footer() {
  return (
    <footer className="mt-auto pb-28 pt-8 px-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
      <div className="max-w-2xl mx-auto text-center space-y-3">
        <div className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-gradient-to-r from-teal-50 to-emerald-50 dark:from-teal-950/30 dark:to-emerald-950/30 border border-teal-200/50 dark:border-teal-800/50">
          <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">
            🇮🇳 Made with ❤️ in India for Bharat
          </span>
        </div>
        <p className="text-xs text-slate-400 dark:text-slate-500">
          © {new Date().getFullYear()} Where Is My Ghar · Direct Owner · Zero Brokerage
        </p>
      </div>
    </footer>
  );
}
