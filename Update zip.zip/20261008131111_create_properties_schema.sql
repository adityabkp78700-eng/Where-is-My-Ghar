/*
# Create properties table for "Where Is My Ghar" rental platform

## Purpose
Stores rental property listings (Hostels, Rental Rooms, Flats) across India.
Public can browse/read listings; only authenticated owners can create, edit, or delete their own listings.

## New Tables
- `properties`
  - `id` (uuid, primary key)
  - `user_id` (uuid, NOT NULL, defaults to auth.uid(), FK to auth.users with ON DELETE CASCADE)
  - `category` (text, NOT NULL, CHECK: 'hostel', 'room', 'flat')
  - `monthly_rent` (integer, NOT NULL, rent in INR per month)
  - `security_deposit` (integer, NOT NULL, deposit in INR)
  - `city` (text, NOT NULL)
  - `state` (text, NOT NULL)
  - `address` (text, NOT NULL, full street address)
  - `landmark` (text, nearby landmark)
  - `pincode` (text, 6-digit Indian pincode)
  - `owner_phone` (text, NOT NULL, 10-digit Indian mobile starting with 6-9)
  - `latitude` (float8, nullable, GPS coordinates)
  - `longitude` (float8, nullable, GPS coordinates)
  - `amenities` (jsonb, default '[]', list of amenity identifiers)
  - `photo_urls` (jsonb, default '[]', up to 3 image URLs in Supabase Storage)
  - `status` (text, NOT NULL, default 'available', CHECK: 'available', 'rented')
  - `last_activity_at` (timestamptz, default now(), for 60-day inactivity flagging)
  - `rented_at` (timestamptz, nullable, set when status changes to 'rented' for 30-day image cleanup)
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now(), auto-updated on change)

## Indexes
- city, category, status, user_id, monthly_rent

## Security (RLS)
- SELECT: Public read (anon + authenticated, USING true)
- INSERT: Authenticated only, must own (WITH CHECK auth.uid() = user_id)
- UPDATE: Authenticated only, must own (USING + WITH CHECK auth.uid() = user_id)
- DELETE: Authenticated only, must own (USING auth.uid() = user_id)
*/

-- Helper function for updated_at (must exist before trigger)
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  NEW.last_activity_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TABLE IF NOT EXISTS properties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  category text NOT NULL CHECK (category IN ('hostel', 'room', 'flat')),
  monthly_rent integer NOT NULL CHECK (monthly_rent > 0),
  security_deposit integer NOT NULL DEFAULT 0 CHECK (security_deposit >= 0),
  city text NOT NULL,
  state text NOT NULL,
  address text NOT NULL,
  landmark text DEFAULT '',
  pincode text DEFAULT '',
  owner_phone text NOT NULL,
  latitude float8,
  longitude float8,
  amenities jsonb NOT NULL DEFAULT '[]'::jsonb,
  photo_urls jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'rented')),
  last_activity_at timestamptz NOT NULL DEFAULT now(),
  rented_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_properties_city ON properties(city);
CREATE INDEX IF NOT EXISTS idx_properties_category ON properties(category);
CREATE INDEX IF NOT EXISTS idx_properties_status ON properties(status);
CREATE INDEX IF NOT EXISTS idx_properties_user_id ON properties(user_id);
CREATE INDEX IF NOT EXISTS idx_properties_monthly_rent ON properties(monthly_rent);

ALTER TABLE properties ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_properties" ON properties;
CREATE POLICY "public_read_properties"
  ON properties FOR SELECT
  TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS "owner_insert_property" ON properties;
CREATE POLICY "owner_insert_property"
  ON properties FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "owner_update_property" ON properties;
CREATE POLICY "owner_update_property"
  ON properties FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "owner_delete_property" ON properties;
CREATE POLICY "owner_delete_property"
  ON properties FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

DROP TRIGGER IF EXISTS update_properties_updated_at ON properties;
CREATE TRIGGER update_properties_updated_at
  BEFORE UPDATE ON properties
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();