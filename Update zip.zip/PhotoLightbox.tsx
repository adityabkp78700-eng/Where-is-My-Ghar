import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Minus, Plus, RotateCcw, X, ZoomIn } from 'lucide-react';

interface PhotoLightboxProps {
  photos: string[];
  initialIndex: number;
  onClose: () => void;
}

const MAX_ZOOM = 2.5;
const MIN_ZOOM = 1;

export default function PhotoLightbox({ photos, initialIndex, onClose }: PhotoLightboxProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [zoom, setZoom] = useState(MIN_ZOOM);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const lastTapRef = useRef(0);
  const pinchDistanceRef = useRef<number | null>(null);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);
  const lastTouchRef = useRef<{ x: number; y: number } | null>(null);
  const hasDraggedRef = useRef(false);

  const resetZoom = () => {
    setZoom(MIN_ZOOM);
    setOffset({ x: 0, y: 0 });
  };

  const changePhoto = (direction: 1 | -1) => {
    setCurrentIndex((index) => (index + direction + photos.length) % photos.length);
    resetZoom();
  };

  const setZoomLevel = (nextZoom: number) => {
    const clampedZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, nextZoom));
    setZoom(clampedZoom);
    if (clampedZoom === MIN_ZOOM) setOffset({ x: 0, y: 0 });
  };

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
      if (event.key === 'ArrowLeft' && photos.length > 1) changePhoto(-1);
      if (event.key === 'ArrowRight' && photos.length > 1) changePhoto(1);
      if (event.key === '+' || event.key === '=') setZoomLevel(zoom + 0.25);
      if (event.key === '-') setZoomLevel(zoom - 0.25);
      if (event.key === '0') resetZoom();
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [onClose, photos.length, zoom]);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
    };
  }, []);

  const handleTouchStart = (event: React.TouchEvent<HTMLDivElement>) => {
    if (event.touches.length === 2) {
      pinchDistanceRef.current = getTouchDistance(event.touches[0], event.touches[1]);
      touchStartRef.current = null;
      lastTouchRef.current = null;
      return;
    }

    const touch = event.touches[0];
    touchStartRef.current = { x: touch.clientX, y: touch.clientY };
    lastTouchRef.current = { x: touch.clientX, y: touch.clientY };
    hasDraggedRef.current = false;
  };

  const handleTouchMove = (event: React.TouchEvent<HTMLDivElement>) => {
    if (event.touches.length === 2 && pinchDistanceRef.current) {
      event.preventDefault();
      const distance = getTouchDistance(event.touches[0], event.touches[1]);
      setZoomLevel(zoom * (distance / pinchDistanceRef.current));
      pinchDistanceRef.current = distance;
      return;
    }

    if (event.touches.length !== 1 || !lastTouchRef.current || zoom === MIN_ZOOM) return;
    event.preventDefault();
    const touch = event.touches[0];
    const deltaX = touch.clientX - lastTouchRef.current.x;
    const deltaY = touch.clientY - lastTouchRef.current.y;
    setOffset((current) => ({ x: current.x + deltaX, y: current.y + deltaY }));
    lastTouchRef.current = { x: touch.clientX, y: touch.clientY };
    hasDraggedRef.current = true;
  };

  const handleTouchEnd = (event: React.TouchEvent<HTMLDivElement>) => {
    if (pinchDistanceRef.current) {
      pinchDistanceRef.current = null;
      return;
    }

    const start = touchStartRef.current;
    const end = event.changedTouches[0];
    touchStartRef.current = null;
    lastTouchRef.current = null;
    if (!start || !end || zoom !== MIN_ZOOM || hasDraggedRef.current) return;

    const deltaX = end.clientX - start.x;
    if (photos.length > 1 && Math.abs(deltaX) > 55) {
      changePhoto(deltaX < 0 ? 1 : -1);
      return;
    }

    const now = Date.now();
    if (now - lastTapRef.current < 280) {
      setZoomLevel(zoom === MIN_ZOOM ? 2 : MIN_ZOOM);
    }
    lastTapRef.current = now;
  };

  if (photos.length === 0) return null;

  return (
    <div className="fixed inset-0 z-[90] flex flex-col bg-slate-950/95 text-white backdrop-blur-md" role="dialog" aria-modal="true" aria-label="Property photo viewer">
      <div className="flex items-center justify-between px-4 py-4 sm:px-6">
        <p className="text-sm font-semibold text-white/75">{currentIndex + 1} / {photos.length}</p>
        <button onClick={onClose} className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 transition-colors hover:bg-white/20 btn-press" aria-label="Close photo viewer">
          <X className="h-5 w-5" />
        </button>
      </div>

      <div
        className="relative flex min-h-0 flex-1 items-center justify-center overflow-hidden px-3 sm:px-16"
        style={{ touchAction: 'none' }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onDoubleClick={() => setZoomLevel(zoom === MIN_ZOOM ? 2 : MIN_ZOOM)}
      >
        {photos.length > 1 && (
          <button onClick={() => changePhoto(-1)} className="absolute left-3 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-black/35 transition-colors hover:bg-black/60 sm:left-5" aria-label="Previous photo">
            <ChevronLeft className="h-6 w-6" />
          </button>
        )}

        <img
          src={photos[currentIndex]}
          alt={`Property photo ${currentIndex + 1}`}
          draggable={false}
          className="max-h-full max-w-full select-none object-contain transition-transform duration-200 ease-out"
          style={{ transform: `translate(${offset.x}px, ${offset.y}px) scale(${zoom})` }}
        />

        {photos.length > 1 && (
          <button onClick={() => changePhoto(1)} className="absolute right-3 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-black/35 transition-colors hover:bg-black/60 sm:right-5" aria-label="Next photo">
            <ChevronRight className="h-6 w-6" />
          </button>
        )}
      </div>

      <div className="flex flex-col items-center gap-3 px-4 pb-6 pt-4">
        <div className="flex items-center gap-2 rounded-2xl bg-white/10 p-1.5">
          <button onClick={() => setZoomLevel(zoom - 0.25)} disabled={zoom === MIN_ZOOM} className="flex h-10 w-10 items-center justify-center rounded-xl transition-colors hover:bg-white/15 disabled:opacity-35" aria-label="Zoom out">
            <Minus className="h-5 w-5" />
          </button>
          <button onClick={resetZoom} className="flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold text-white/80 transition-colors hover:bg-white/15" aria-label="Reset zoom">
            <RotateCcw className="h-3.5 w-3.5" /> Reset Zoom
          </button>
          <button onClick={() => setZoomLevel(zoom + 0.25)} disabled={zoom === MAX_ZOOM} className="flex h-10 w-10 items-center justify-center rounded-xl transition-colors hover:bg-white/15 disabled:opacity-35" aria-label="Zoom in">
            <Plus className="h-5 w-5" />
          </button>
        </div>
        <div className="flex items-center gap-2 text-xs text-white/55">
          <ZoomIn className="h-3.5 w-3.5" /> Pinch or double-tap to zoom
        </div>
        {photos.length > 1 && <div className="flex max-w-full gap-1.5 overflow-x-auto no-scrollbar">{photos.map((photo, index) => <button key={photo} onClick={() => { setCurrentIndex(index); resetZoom(); }} className={`h-1.5 rounded-full transition-all ${index === currentIndex ? 'w-8 bg-teal-300' : 'w-2 bg-white/35'}`} aria-label={`View photo ${index + 1}`} />)}</div>}
      </div>
    </div>
  );
}

function getTouchDistance(first: React.Touch, second: React.Touch): number {
  return Math.hypot(second.clientX - first.clientX, second.clientY - first.clientY);
}
