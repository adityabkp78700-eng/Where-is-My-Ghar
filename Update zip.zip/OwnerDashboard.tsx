import { useState, useEffect, useCallback } from 'react';
import { Plus, Pencil, Trash2, ToggleLeft, ToggleRight, Loader2, Building2, TrendingUp, CircleDollarSign, Clock, Eye, MessageSquare, ArrowUpRight, LockKeyhole } from 'lucide-react';
import { Property, CATEGORY_LABELS, formatRent, isInactive } from '@/lib/types';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import SkeletonCard from '@/components/SkeletonCard';

interface OwnerDashboardProps {
  onEdit: (p: Property) => void;
  onAddNew: () => void;
  refreshKey: number;
  onRented: () => void;
}

export default function OwnerDashboard({ onEdit, onAddNew, refreshKey, onRented }: OwnerDashboardProps) {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  const fetchProperties = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('properties')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      showToast('Failed to load listings', 'error');
    } else {
      setProperties(data || []);
    }
    setLoading(false);
  }, [user, showToast]);

  useEffect(() => {
    fetchProperties();
  }, [fetchProperties, refreshKey]);

  if (!user) {
    return (
      <div className="space-y-4">
        <section className="overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 p-5 text-white shadow-[0_16px_32px_rgba(15,23,42,0.16)]">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-300">Owner workspace</p>
              <h2 className="mt-2 text-2xl font-bold tracking-tight">Grow your rental business</h2>
              <p className="mt-2 max-w-sm text-sm leading-6 text-slate-300">List properties, manage availability, and connect with genuine renters directly.</p>
            </div>
            <div className="rounded-2xl bg-white/10 p-3"><LockKeyhole className="h-6 w-6 text-emerald-300" /></div>
          </div>
          <button onClick={onAddNew} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-400 px-4 py-3 text-sm font-bold text-slate-950 transition-transform btn-press hover:bg-emerald-300">
            Sign in to list a property <ArrowUpRight className="h-4 w-4" />
          </button>
        </section>
        <div className="grid grid-cols-3 gap-2">
          {[{ label: 'Active Listings', value: '0', icon: Building2 }, { label: 'Views', value: '0', icon: Eye }, { label: 'Inquiries', value: '0', icon: MessageSquare }].map((stat) => {
            const Icon = stat.icon;
            return <div key={stat.label} className="rounded-2xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900"><Icon className="h-4 w-4 text-emerald-500" /><p className="mt-3 text-xl font-bold text-slate-900 dark:text-white">{stat.value}</p><p className="mt-1 text-[10px] font-medium leading-4 text-slate-500">{stat.label}</p></div>;
          })}
        </div>
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-5 text-center dark:border-slate-700 dark:bg-slate-900"><p className="text-sm font-semibold text-slate-700 dark:text-slate-200">Your professional rental dashboard</p><p className="mt-1 text-xs leading-5 text-slate-500">Sign in to see your listings, status updates, and property performance here.</p></div>
      </div>
    );
  }

  const toggleStatus = async (p: Property) => {
    setBusyId(p.id);
    const newStatus = p.status === 'available' ? 'rented' : 'available';
    const updates: Record<string, string | null> = {
      status: newStatus,
      last_activity_at: new Date().toISOString(),
    };
    if (newStatus === 'rented') updates.rented_at = new Date().toISOString();
    else updates.rented_at = null;

    const { error } = await supabase.from('properties').update(updates).eq('id', p.id);
    if (error) {
      showToast('Failed to update status', 'error');
    } else {
      showToast(`Marked as ${newStatus === 'rented' ? 'Rented Out' : 'Available'}`, 'success');
      if (newStatus === 'rented') onRented();
      fetchProperties();
    }
    setBusyId(null);
  };

  const handleDelete = async (p: Property) => {
    if (!confirm('Delete this listing? Photos will be permanently removed.')) return;

    setBusyId(p.id);
    try {
      // Delete photos from storage
      for (const url of p.photo_urls) {
        try {
          const urlObj = new URL(url);
          const parts = urlObj.pathname.split('/property-photos/');
          if (parts.length > 1) {
            const filePath = parts[1];
            await supabase.storage.from('property-photos').remove([decodeURIComponent(filePath)]);
          }
        } catch {
          // skip invalid URLs
        }
      }

      const { error } = await supabase.from('properties').delete().eq('id', p.id);
      if (error) throw error;

      showToast('Listing deleted', 'success');
      fetchProperties();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to delete', 'error');
    }
    setBusyId(null);
  };

  const availableCount = properties.filter((p) => p.status === 'available').length;
  const rentedCount = properties.filter((p) => p.status === 'rented').length;
  const totalRent = properties.filter((p) => p.status === 'available').reduce((sum, p) => sum + p.monthly_rent, 0);
  const inactiveCount = properties.filter((p) => isInactive(p.last_activity_at) && p.status === 'available').length;

  if (loading) {
    return (
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          {Array.from({ length: 2 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-end justify-between px-1">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-emerald-600 dark:text-emerald-400">Owner workspace</p>
          <h2 className="mt-1 text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Your properties</h2>
        </div>
        <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300">Pro Dashboard</span>
      </div>
      {/* Stats cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-4 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-900/30 flex items-center justify-center">
              <Building2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            </div>
            <span className="text-xs font-semibold text-slate-400">Active Listings</span>
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white">{availableCount}</p>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-2xl p-4 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg bg-orange-50 dark:bg-orange-900/30 flex items-center justify-center">
              <Clock className="w-4 h-4 text-orange-600 dark:text-orange-400" />
            </div>
            <span className="text-xs font-semibold text-slate-400">Rented Out</span>
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white">{rentedCount}</p>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-2xl p-4 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg bg-teal-50 dark:bg-teal-900/30 flex items-center justify-center">
              <CircleDollarSign className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            </div>
            <span className="text-xs font-semibold text-slate-400">Total Rent Value</span>
          </div>
          <p className="text-xl font-bold text-slate-900 dark:text-white">{formatRent(totalRent)}</p>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-2xl p-4 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-900/30 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            </div>
            <span className="text-xs font-semibold text-slate-400">Inactive 60d+</span>
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white">{inactiveCount}</p>
        </div>
      </div>

      {/* Listings */}
      {properties.length === 0 ? (
        <div className="text-center py-16 flex flex-col items-center gap-3">
          <div className="w-16 h-16 rounded-full bg-emerald-50 dark:bg-emerald-900/30 flex items-center justify-center">
            <Building2 className="w-8 h-8 text-emerald-400" />
          </div>
          <p className="text-sm font-bold text-slate-700 dark:text-slate-200">No listings yet</p>
          <p className="text-xs text-slate-400 max-w-[280px]">List your first property and start connecting with genuine renters directly — zero brokerage.</p>
          <button
            onClick={onAddNew}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl gradient-teal-emerald text-white text-sm font-semibold btn-press mt-1"
          >
            <Plus className="w-3.5 h-3.5" /> List Your First Property
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {properties.map((p) => {
            const inactive = isInactive(p.last_activity_at);
            return (
              <div
                key={p.id}
                className="bg-white dark:bg-slate-800 rounded-2xl p-3 border border-slate-200 dark:border-slate-700 card-tap"
              >
                <div className="flex gap-3">
                  {/* Thumbnail */}
                  <div className="flex-shrink-0 w-16 h-16 rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-700">
                    {p.photo_urls[0] ? (
                      <img src={p.photo_urls[0]} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Building2 className="w-6 h-6 text-slate-300 dark:text-slate-600" />
                      </div>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-xs font-bold text-teal-600 dark:text-teal-400">{CATEGORY_LABELS[p.category]}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        p.status === 'available'
                          ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400'
                          : 'bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400'
                      }`}>
                        {p.status === 'available' ? 'Available' : 'Rented'}
                      </span>
                      {inactive && p.status === 'available' && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400">
                          Inactive
                        </span>
                      )}
                    </div>
                    <p className="text-sm font-bold text-slate-900 dark:text-white">{formatRent(p.monthly_rent)}/mo</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{p.city}, {p.state}</p>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col gap-1.5 items-end">
                    <button
                      onClick={() => toggleStatus(p)}
                      disabled={busyId === p.id}
                      className="flex items-center gap-1 text-xs font-medium text-slate-500 dark:text-slate-400 btn-press disabled:opacity-50"
                    >
                      {busyId === p.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : p.status === 'available' ? <ToggleRight className="w-5 h-5" /> : <ToggleLeft className="w-5 h-5" />}
                    </button>
                    <button
                      onClick={() => onEdit(p)}
                      className="w-7 h-7 rounded-lg bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center btn-press"
                    >
                      <Pencil className="w-3.5 h-3.5 text-blue-500" />
                    </button>
                    <button
                      onClick={() => handleDelete(p)}
                      disabled={busyId === p.id}
                      className="w-7 h-7 rounded-lg bg-red-50 dark:bg-red-900/30 flex items-center justify-center btn-press disabled:opacity-50"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-red-500" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* FAB */}
      <button
        onClick={onAddNew}
        className="fixed bottom-24 right-4 w-14 h-14 rounded-full gradient-teal-emerald text-white shadow-xl shadow-teal-500/30 flex items-center justify-center btn-press z-30 gpu-layer"
        aria-label="List new property"
      >
        <Plus className="w-6 h-6" strokeWidth={2.5} />
      </button>
    </div>
  );
}
