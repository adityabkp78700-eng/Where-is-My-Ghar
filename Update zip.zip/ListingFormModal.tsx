import { useState, useEffect, useRef } from 'react';
import { X, Camera, Crosshair, Loader2, Trash2, Plus } from 'lucide-react';
import { Property, PropertyCategory, PropertyInput, AMENITY_LIST, CATEGORY_LABELS } from '@/lib/types';
import { compressToWebP, validateIndianPhone, validatePincode } from '@/lib/imageUtils';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';

interface ListingFormModalProps {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  editingProperty?: Property | null;
}

const INDIAN_STATES = [
  'Andhra Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Delhi', 'Goa', 'Gujarat',
  'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh',
  'Maharashtra', 'Odisha', 'Punjab', 'Rajasthan', 'Tamil Nadu', 'Telangana',
  'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Chandigarh', 'Jammu & Kashmir',
];

export default function ListingFormModal({ open, onClose, onSaved, editingProperty }: ListingFormModalProps) {
  const { user } = useAuth();
  const { showToast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState<PropertyInput>({
    category: 'room',
    monthly_rent: 0,
    security_deposit: 0,
    city: '',
    state: '',
    address: '',
    landmark: '',
    pincode: '',
    owner_phone: '',
    latitude: null,
    longitude: null,
    amenities: [],
    photo_urls: [],
  });
  const [photos, setPhotos] = useState<File[]>([]);
  const [existingPhotos, setExistingPhotos] = useState<string[]>([]);
  const [photoPreviews, setPhotoPreviews] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (open) {
      if (editingProperty) {
        setForm({
          category: editingProperty.category,
          monthly_rent: editingProperty.monthly_rent,
          security_deposit: editingProperty.security_deposit,
          city: editingProperty.city,
          state: editingProperty.state,
          address: editingProperty.address,
          landmark: editingProperty.landmark,
          pincode: editingProperty.pincode,
          owner_phone: editingProperty.owner_phone,
          latitude: editingProperty.latitude,
          longitude: editingProperty.longitude,
          amenities: editingProperty.amenities,
          photo_urls: editingProperty.photo_urls,
        });
        setExistingPhotos(editingProperty.photo_urls);
        setPhotoPreviews(editingProperty.photo_urls);
      } else {
        setForm({
          category: 'room', monthly_rent: 0, security_deposit: 0, city: '', state: '',
          address: '', landmark: '', pincode: '', owner_phone: '', latitude: null,
          longitude: null, amenities: [], photo_urls: [],
        });
        setExistingPhotos([]);
        setPhotoPreviews([]);
      }
      setPhotos([]);
      setErrors({});
    }
  }, [open, editingProperty]);

  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
      return () => { document.body.style.overflow = ''; };
    }
  }, [open]);

  if (!open) return null;

  const update = (field: keyof PropertyInput, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: '' }));
  };

  const toggleAmenity = (id: string) => {
    setForm((prev) => ({
      ...prev,
      amenities: prev.amenities.includes(id)
        ? prev.amenities.filter((a) => a !== id)
        : [...prev.amenities, id],
    }));
  };

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    const remaining = 3 - (existingPhotos.length + photos.length);
    const toAdd = files.slice(0, remaining);

    const previews: string[] = [];
    for (const file of toAdd) {
      previews.push(URL.createObjectURL(file));
    }
    setPhotos((prev) => [...prev, ...toAdd]);
    setPhotoPreviews((prev) => [...prev, ...previews]);
    e.target.value = '';
  };

  const removePhoto = (index: number) => {
    if (index < existingPhotos.length) {
      const idx = index;
      setExistingPhotos((prev) => prev.filter((_, i) => i !== idx));
      setPhotoPreviews((prev) => prev.filter((_, i) => i !== idx));
    } else {
      const idx = index - existingPhotos.length;
      setPhotos((prev) => prev.filter((_, i) => i !== idx));
      setPhotoPreviews((prev) => prev.filter((_, i) => i !== index));
    }
  };

  const handleGPS = () => {
    setGpsLoading(true);
    if (!navigator.geolocation) {
      showToast('GPS not supported on this device', 'error');
      setGpsLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        update('latitude', pos.coords.latitude);
        update('longitude', pos.coords.longitude);
        showToast('Location captured!', 'success');
        setGpsLoading(false);
      },
      (err) => {
        let msg = 'Could not get location. ';
        if (err.code === err.PERMISSION_DENIED) msg = 'Location permission denied. Please enable GPS in settings.';
        else if (err.code === err.POSITION_UNAVAILABLE) msg = 'Location unavailable. Check your GPS signal.';
        else if (err.code === err.TIMEOUT) msg = 'Location request timed out. Try again.';
        showToast(msg, 'error');
        setGpsLoading(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (form.monthly_rent <= 0) e.monthly_rent = 'Enter monthly rent';
    if (!form.city.trim()) e.city = 'Enter city';
    if (!form.state.trim()) e.state = 'Select state';
    if (!form.address.trim()) e.address = 'Enter full address';
    if (!validateIndianPhone(form.owner_phone)) e.owner_phone = 'Enter valid 10-digit Indian mobile (starts 6-9)';
    if (form.pincode && !validatePincode(form.pincode)) e.pincode = 'Enter valid 6-digit pincode';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const uploadPhotos = async (): Promise<string[]> => {
    const urls = [...existingPhotos];
    for (const file of photos) {
      const compressed = await compressToWebP(file);
      const ext = 'webp';
      const fileName = `${user!.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;

      const { error } = await supabase.storage
        .from('property-photos')
        .upload(fileName, compressed, { contentType: 'image/webp' });

      if (error) throw new Error(`Photo upload failed: ${error.message}`);

      const { data: urlData } = supabase.storage
        .from('property-photos')
        .getPublicUrl(fileName);
      urls.push(urlData.publicUrl);
    }
    return urls;
  };

  const handleSubmit = async () => {
    if (!validate() || !user) return;
    setBusy(true);

    try {
      const photo_urls = await uploadPhotos();

      const payload = {
        ...form,
        monthly_rent: Number(form.monthly_rent),
        security_deposit: Number(form.security_deposit),
        photo_urls,
        amenities: form.amenities,
        latitude: form.latitude,
        longitude: form.longitude,
      };

      if (editingProperty) {
        const { error } = await supabase
          .from('properties')
          .update(payload)
          .eq('id', editingProperty.id);
        if (error) throw error;
        showToast('Listing updated!', 'success');
      } else {
        const { error } = await supabase
          .from('properties')
          .insert(payload);
        if (error) throw error;
        showToast('Property listed!', 'success');
      }

      onSaved();
      onClose();
    } catch (err: any) {
      showToast(err.message || 'Failed to save listing', 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm backdrop-fade" onClick={onClose} />

      <div className="relative w-full sm:max-w-lg max-h-[92vh] overflow-y-auto bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl gpu-scroll no-scrollbar sheet-enter">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-3 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            {editingProperty ? 'Edit Listing' : 'List New Property'}
          </h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center btn-press">
            <X className="w-4 h-4 text-slate-500" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Category */}
          <div>
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Category</label>
            <div className="grid grid-cols-3 gap-2">
              {(['hostel', 'room', 'flat'] as PropertyCategory[]).map((c) => (
                <button
                  key={c}
                  onClick={() => update('category', c)}
                  className={`py-2.5 rounded-xl text-sm font-semibold nav-pill btn-press ${
                    form.category === c
                      ? 'gradient-teal-emerald text-white shadow-md shadow-teal-500/20'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {CATEGORY_LABELS[c]}
                </button>
              ))}
            </div>
          </div>

          {/* Rent + Deposit */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Monthly Rent (₹)</label>
              <input
                type="number"
                value={form.monthly_rent || ''}
                onChange={(e) => update('monthly_rent', e.target.value)}
                placeholder="e.g. 8000"
                className="w-full bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-2.5 text-sm border border-slate-200 dark:border-slate-700 outline-none focus:border-teal-400 transition-colors text-slate-800 dark:text-slate-100"
              />
              {errors.monthly_rent && <p className="text-[10px] text-red-500 mt-1">{errors.monthly_rent}</p>}
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Security Deposit (₹)</label>
              <input
                type="number"
                value={form.security_deposit || ''}
                onChange={(e) => update('security_deposit', e.target.value)}
                placeholder="e.g. 10000"
                className="w-full bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-2.5 text-sm border border-slate-200 dark:border-slate-700 outline-none focus:border-teal-400 transition-colors text-slate-800 dark:text-slate-100"
              />
            </div>
          </div>

          {/* City + State */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">City</label>
              <input
                type="text"
                value={form.city}
                onChange={(e) => update('city', e.target.value)}
                placeholder="e.g. Pune"
                className="w-full bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-2.5 text-sm border border-slate-200 dark:border-slate-700 outline-none focus:border-teal-400 transition-colors text-slate-800 dark:text-slate-100"
              />
              {errors.city && <p className="text-[10px] text-red-500 mt-1">{errors.city}</p>}
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">State</label>
              <select
                value={form.state}
                onChange={(e) => update('state', e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-2.5 text-sm border border-slate-200 dark:border-slate-700 outline-none focus:border-teal-400 transition-colors text-slate-800 dark:text-slate-100"
              >
                <option value="">Select</option>
                {INDIAN_STATES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
              {errors.state && <p className="text-[10px] text-red-500 mt-1">{errors.state}</p>}
            </div>
          </div>

          {/* Address */}
          <div>
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Full Address</label>
            <textarea
              value={form.address}
              onChange={(e) => update('address', e.target.value)}
              placeholder="House no, street, area..."
              rows={2}
              className="w-full bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-2.5 text-sm border border-slate-200 dark:border-slate-700 outline-none focus:border-teal-400 transition-colors text-slate-800 dark:text-slate-100 resize-none"
            />
            {errors.address && <p className="text-[10px] text-red-500 mt-1">{errors.address}</p>}
          </div>

          {/* Landmark + Pincode */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Nearby Landmark</label>
              <input
                type="text"
                value={form.landmark}
                onChange={(e) => update('landmark', e.target.value)}
                placeholder="e.g. Near metro station"
                className="w-full bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-2.5 text-sm border border-slate-200 dark:border-slate-700 outline-none focus:border-teal-400 transition-colors text-slate-800 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Pincode</label>
              <input
                type="text"
                value={form.pincode}
                onChange={(e) => update('pincode', e.target.value)}
                placeholder="6-digit"
                maxLength={6}
                className="w-full bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-2.5 text-sm border border-slate-200 dark:border-slate-700 outline-none focus:border-teal-400 transition-colors text-slate-800 dark:text-slate-100"
              />
              {errors.pincode && <p className="text-[10px] text-red-500 mt-1">{errors.pincode}</p>}
            </div>
          </div>

          {/* Owner Phone */}
          <div>
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Owner Mobile Number</label>
            <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-2.5 border border-slate-200 dark:border-slate-700 focus-within:border-teal-400 transition-colors">
              <span className="text-sm text-slate-500 font-medium">+91</span>
              <input
                type="tel"
                value={form.owner_phone}
                onChange={(e) => update('owner_phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder="10-digit mobile"
                maxLength={10}
                className="flex-1 bg-transparent text-sm outline-none text-slate-800 dark:text-slate-100"
              />
            </div>
            {errors.owner_phone && <p className="text-[10px] text-red-500 mt-1">{errors.owner_phone}</p>}
          </div>

          {/* GPS Location */}
          <div>
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Location (GPS)</label>
            <button
              onClick={handleGPS}
              disabled={gpsLoading}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 border-dashed border-teal-300 dark:border-teal-700 text-teal-600 dark:text-teal-400 text-sm font-semibold btn-press hover:bg-teal-50 dark:hover:bg-teal-950/30 transition-colors disabled:opacity-50"
            >
              {gpsLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Crosshair className="w-4 h-4" />}
              {form.latitude != null ? `Location set (${form.latitude.toFixed(4)}, ${form.longitude?.toFixed(4)})` : 'Use My Current Location'}
            </button>
          </div>

          {/* Amenities */}
          <div>
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Amenities</label>
            <div className="grid grid-cols-4 gap-2">
              {AMENITY_LIST.map((a) => {
                const active = form.amenities.includes(a.id);
                return (
                  <button
                    key={a.id}
                    onClick={() => toggleAmenity(a.id)}
                    className={`flex flex-col items-center gap-1 py-2 rounded-xl text-[10px] font-medium nav-pill btn-press ${
                      active
                        ? 'bg-teal-50 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400 border border-teal-200 dark:border-teal-700'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-transparent'
                    }`}
                  >
                    <span className="text-lg">{a.icon}</span>
                    {a.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Photos */}
          <div>
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">
              Photos (Optional, Max 3)
            </label>
            <div className="flex gap-2 overflow-x-auto no-scrollbar gpu-scroll">
              {photoPreviews.map((url, i) => (
                <div key={i} className="relative flex-shrink-0 w-20 h-20 rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800">
                  <img src={url} alt={`Photo ${i + 1}`} className="w-full h-full object-cover" />
                  <button
                    onClick={() => removePhoto(i)}
                    className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full bg-black/60 flex items-center justify-center"
                  >
                    <Trash2 className="w-3 h-3 text-white" />
                  </button>
                </div>
              ))}
              {photoPreviews.length < 3 && (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-shrink-0 w-20 h-20 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-600 flex flex-col items-center justify-center gap-1 text-slate-400 btn-press hover:border-teal-400 transition-colors"
                >
                  <Camera className="w-5 h-5" />
                  <span className="text-[9px] font-medium">Upload</span>
                </button>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handlePhotoSelect}
              className="hidden"
            />
          </div>

          {/* Submit */}
          <button
            onClick={handleSubmit}
            disabled={busy}
            className="w-full py-3.5 rounded-xl gradient-teal-emerald text-white font-semibold text-sm btn-press shadow-md shadow-teal-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {busy ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving...</> : editingProperty ? 'Update Listing' : 'List Property'}
          </button>
        </div>
      </div>
    </div>
  );
}
