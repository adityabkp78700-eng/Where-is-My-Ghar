import { Phone, MessageCircle, MapPin, Share2, MapPinned, Heart, BadgeCheck, GitCompareArrows } from 'lucide-react';
import { Property, CATEGORY_LABELS, AMENITY_MAP, formatRent, timeAgo, isInactive } from '@/lib/types';
import { useSaved } from '@/context/SavedContext';
import { useToast } from '@/context/ToastContext';

const DEFAULT_COVER = 'https://images.pexels.com/photos/20666870/pexels-photo-20666870.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

interface PropertyCardProps {
  property: Property;
  onOpenDetail: (p: Property) => void;
  onOpenPhoto: (photos: string[], index: number) => void;
  onCallOwner: (p: Property) => void;
  onWhatsAppOwner: (p: Property) => void;
  compareSelected?: boolean;
  onToggleCompare?: (p: Property) => void;
  compareMode?: boolean;
}

export default function PropertyCard({
  property,
  onOpenDetail,
  onOpenPhoto,
  onCallOwner,
  onWhatsAppOwner,
  compareSelected,
  onToggleCompare,
  compareMode,
}: PropertyCardProps) {
  const coverPhoto = property.photo_urls?.[0] || DEFAULT_COVER;
  const inactive = isInactive(property.last_activity_at);
  const { isSaved, toggleSave } = useSaved();
  const { showToast } = useToast();
  const saved = isSaved(property.id);

  const handleShare = async () => {
    const baseUrl = window.location.origin;
    const shareUrl = `${baseUrl}/property/${property.id}`;
    const text = `Check out this ${CATEGORY_LABELS[property.category]} for rent in ${property.city} — ${formatRent(property.monthly_rent)}/month on Where Is My Ghar: ${shareUrl}`;
    if (navigator.share) {
      try { await navigator.share({ text, url: shareUrl }); return; } catch { /* user cancelled share */ }
    }
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleSave(property);
    showToast(saved ? 'Removed from saved' : 'Added to saved', 'success');
    navigator.vibrate?.(8);
  };

  const handleDirections = () => {
    if (property.latitude && property.longitude) {
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${property.latitude},${property.longitude}`, '_blank');
    } else {
      const query = encodeURIComponent(`${property.address}, ${property.city}, ${property.state} ${property.pincode}`);
      window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank');
    }
  };

  return (
    <div
      onClick={() => onOpenDetail(property)}
      className={`card-tap overflow-hidden rounded-[26px] border bg-white shadow-[0_12px_32px_rgba(15,23,42,0.1)] dark:bg-slate-800 cursor-pointer fade-in-up transition-colors ${
        compareSelected ? 'border-teal-500 ring-2 ring-teal-500/20 dark:border-teal-400' : 'border-slate-200/80 dark:border-slate-700'
      }`}
    >
      {/* Cover Image */}
      <div className="relative h-[270px] bg-slate-100 dark:bg-slate-700 overflow-hidden sm:h-[340px]">
        <button
          onClick={(event) => {
            event.stopPropagation();
            if (property.photo_urls.length > 0) onOpenPhoto(property.photo_urls, 0);
          }}
          className="relative block h-full w-full cursor-zoom-in text-left"
          aria-label="Open property photos"
        >
          <img
            src={coverPhoto}
            alt={`${CATEGORY_LABELS[property.category]} in ${property.city}`}
            className="h-full w-full object-cover"
            loading="lazy"
          />
          {property.photo_urls.length > 0 && (
            <span className="absolute bottom-3 right-3 rounded-full bg-slate-950/65 px-2.5 py-1.5 text-[10px] font-semibold text-white backdrop-blur-sm">
              🔍 Tap to Zoom
            </span>
          )}
        </button>

        {/* Top badges */}
        <div className="absolute left-5 top-5 flex gap-2 flex-wrap">
          <span className="rounded-full bg-white px-3.5 py-2 text-[14px] font-bold text-[#1261ad] shadow-sm">
            {CATEGORY_LABELS[property.category]}
          </span>
          {property.is_verified && (
            <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-blue-500/90 backdrop-blur text-[11px] font-bold text-white shadow-sm">
              <BadgeCheck className="w-3 h-3" />
              Verified
            </span>
          )}
          {property.status === 'rented' && (
            <span className="px-2.5 py-1 rounded-full bg-orange-500/90 backdrop-blur text-[11px] font-bold text-white">
              Rented Out
            </span>
          )}
          {inactive && property.status === 'available' && (
            <span className="px-2.5 py-1 rounded-full bg-amber-400/90 backdrop-blur text-[11px] font-bold text-white">
              Inactive
            </span>
          )}
        </div>

        {property.status === 'available' && !inactive && (
          <span className="absolute top-2 right-14 px-2.5 py-1 rounded-full bg-emerald-500/90 backdrop-blur text-[11px] font-bold text-white">
            Available
          </span>
        )}

        <div className="absolute top-2 right-2 flex gap-1.5">
          {compareMode && onToggleCompare && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleCompare(property);
              }}
              className={`w-9 h-9 rounded-full backdrop-blur flex items-center justify-center btn-press transition-all ${
                compareSelected ? 'bg-teal-500 text-white' : 'bg-white/90 text-slate-600'
              }`}
              aria-label="Add to comparison"
            >
              <GitCompareArrows className="w-4 h-4" strokeWidth={2.2} />
            </button>
          )}
          <button
            onClick={handleSave}
            className={`w-9 h-9 rounded-full backdrop-blur flex items-center justify-center btn-press transition-all ${saved ? 'bg-rose-500/90 text-white' : 'bg-white/90 text-slate-600'}`}
            aria-label={saved ? 'Remove from saved' : 'Save property'}
          >
            <Heart className="w-4 h-4" fill={saved ? 'currentColor' : 'none'} strokeWidth={2.2} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-3 space-y-2">
        {/* Rent */}
        <div className="flex items-baseline gap-2">
          <span className="text-lg font-bold text-slate-900 dark:text-white">{formatRent(property.monthly_rent)}</span>
          <span className="text-xs text-slate-500">/month</span>
          <span className="text-xs text-slate-400 ml-auto">Deposit: {formatRent(property.security_deposit)}</span>
        </div>

        {/* Location */}
        <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
          <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
          <span className="truncate">
            {property.landmark ? `${property.landmark}, ` : ''}{property.city}, {property.state}
          </span>
        </div>

        {/* Amenities */}
        {property.amenities.length > 0 && (
          <div className="flex gap-1.5 flex-wrap">
            {property.amenities.slice(0, 5).map((id) => {
              const a = AMENITY_MAP[id];
              if (!a) return null;
              return (
                <span key={id} className="text-base" title={a.label}>
                  {a.icon}
                </span>
              );
            })}
            {property.amenities.length > 5 && (
              <span className="text-[10px] text-slate-400 font-medium self-center">
                +{property.amenities.length - 5} more
              </span>
            )}
          </div>
        )}

        {/* Action buttons */}
        <div className="flex gap-1.5 pt-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onCallOwner(property);
            }}
            className="flex-1 flex items-center justify-center gap-1 py-2 rounded-lg bg-teal-50 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400 text-xs font-semibold btn-press hover:bg-teal-100 dark:hover:bg-teal-900/50 transition-colors"
          >
            <Phone className="w-3.5 h-3.5" />
            Call
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onWhatsAppOwner(property);
            }}
            className="flex-1 flex items-center justify-center gap-1 py-2 rounded-lg bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400 text-xs font-semibold btn-press hover:bg-green-100 dark:hover:bg-green-900/50 transition-colors"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            WhatsApp
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleDirections();
            }}
            className="flex items-center justify-center w-9 py-2 rounded-lg bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 btn-press hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors"
            aria-label="Directions"
          >
            <MapPinned className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleShare();
            }}
            className="flex items-center justify-center w-9 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 btn-press hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors"
            aria-label="Share"
          >
            <Share2 className="w-3.5 h-3.5" />
          </button>
        </div>

        <p className="text-[10px] text-slate-400 text-right">{timeAgo(property.created_at)}</p>
      </div>
    </div>
  );
}
