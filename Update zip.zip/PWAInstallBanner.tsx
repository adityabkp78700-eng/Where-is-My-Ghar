import { useState, useEffect } from 'react';
import { Download, X } from 'lucide-react';

export default function PWAInstallBanner() {
  const [show, setShow] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    // Hide if in standalone/installed mode
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
      (navigator as any).standalone === true;
    if (isStandalone) return;

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setTimeout(() => setShow(true), 3000);
    };

    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setShow(false);
    }
    setDeferredPrompt(null);
  };

  if (!show) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 z-50 max-w-2xl mx-auto">
      <div className="bg-slate-900 dark:bg-slate-800 rounded-2xl shadow-xl p-3 flex items-center gap-3 sheet-enter">
        <div className="w-10 h-10 rounded-xl gradient-teal-emerald flex items-center justify-center flex-shrink-0">
          <Download className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-white">Install Where Is My Ghar</p>
          <p className="text-xs text-slate-400">Add to home screen for a faster experience</p>
        </div>
        <button
          onClick={handleInstall}
          className="px-3 py-1.5 rounded-lg gradient-teal-emerald text-white text-xs font-semibold btn-press flex-shrink-0"
        >
          Install
        </button>
        <button onClick={() => setShow(false)} className="w-7 h-7 rounded-full bg-slate-800 dark:bg-slate-700 flex items-center justify-center flex-shrink-0">
          <X className="w-3.5 h-3.5 text-slate-400" />
        </button>
      </div>
    </div>
  );
}
