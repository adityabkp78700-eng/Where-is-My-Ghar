import { X, GitCompareArrows } from 'lucide-react';
import type { Property, PropertyCategory } from '@/lib/types';
import { CATEGORY_LABELS, formatRent, AMENITY_MAP } from '@/lib/types';

interface CompareBarProps {
  properties: Property[];
  onRemove: (id: string) => void;
  onClear: () => void;
  onCompare: () => void;
  max: number;
}

export default function CompareBar({ properties, onRemove, onClear, onCompare, max }: CompareBarProps) {
  if (properties.length === 0) return null;

  return (
    <div className="fixed bottom-[78px] left-0 right-0 z-40 px-4">
      <div className="mx-auto max-w-2xl bg-slate-900 dark:bg-slate-800 rounded-2xl shadow-2xl p-3 sheet-enter">
        <div className="flex items-center gap-2 mb-2">
          <GitCompareArrows className="w-4 h-4 text-teal-400 flex-shrink-0" />
          <span className="text-xs font-semibold text-white">
            {properties.length} selected for comparison
          </span>
          <span className="text-[10px] text-slate-400">({max} max)</span>
          <button onClick={onClear} className="ml-auto text-xs text-slate-400 hover:text-white transition-colors">
            Clear
          </button>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex gap-2 overflow-x-auto no-scrollbar flex-1">
            {properties.map((p) => (
              <div
                key={p.id}
                className="flex-shrink-0 flex items-center gap-1.5 rounded-lg bg-slate-800 dark:bg-slate-700 px-2.5 py-1.5"
              >
                <span className="text-xs text-white font-medium truncate max-w-[100px]">
                  {formatRent(p.monthly_rent)}/mo
                </span>
                <button
                  onClick={() => onRemove(p.id)}
                  className="w-4 h-4 rounded-full bg-slate-600 flex items-center justify-center flex-shrink-0"
                >
                  <X className="w-2.5 h-2.5 text-white" />
                </button>
              </div>
            ))}
          </div>
          <button
            onClick={onCompare}
            disabled={properties.length < 2}
            className="flex-shrink-0 px-4 py-2 rounded-xl gradient-teal-emerald text-white text-xs font-bold btn-press disabled:opacity-40"
          >
            Compare
          </button>
        </div>
      </div>
    </div>
  );
}

interface CompareSheetProps {
  properties: Property[];
  onClose: () => void;
}

export function CompareSheet({ properties, onClose }: CompareSheetProps) {
  const rows: { label: string; getValue: (p: Property) => string | React.ReactNode; isHighlight?: boolean }[] = [
    { label: 'Rent', getValue: (p) => formatRent(p.monthly_rent), isHighlight: true },
    { label: 'Deposit', getValue: (p) => formatRent(p.security_deposit) },
    { label: 'Category', getValue: (p) => CATEGORY_LABELS[p.category as PropertyCategory] },
    { label: 'City', getValue: (p) => p.city },
    { label: 'State', getValue: (p) => p.state },
    { label: 'Address', getValue: (p) => p.address },
    { label: 'Landmark', getValue: (p) => p.landmark || '—' },
    { label: 'Pincode', getValue: (p) => p.pincode || '—' },
    {
      label: 'Amenities',
      getValue: (p) => (
        <div className="flex flex-wrap gap-1 justify-center">
          {p.amenities.length === 0 ? (
            <span className="text-slate-400 text-xs">None</span>
          ) : (
            p.amenities.map((id) => {
              const a = AMENITY_MAP[id];
              if (!a) return null;
              return (
                <span key={id} className="text-lg" title={a.label}>
                  {a.icon}
                </span>
              );
            })
          )}
        </div>
      ),
    },
    { label: 'Status', getValue: (p) => (p.status === 'available' ? 'Available' : 'Rented Out') },
    { label: 'Verified', getValue: (p) => (p.is_verified ? 'Yes' : 'No') },
  ];

  const cheapestRent = Math.min(...properties.map((p) => p.monthly_rent));
  const lowestDeposit = Math.min(...properties.map((p) => p.security_deposit));

  return (
    <div className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm backdrop-fade" onClick={onClose} />

      <div className="relative w-full sm:max-w-2xl max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl gpu-scroll no-scrollbar sheet-enter">
        <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-3 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <GitCompareArrows className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Side-by-Side Comparison</h2>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center btn-press">
            <X className="w-4 h-4 text-slate-500" />
          </button>
        </div>

        <div className="overflow-x-auto no-scrollbar gpu-scroll">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800">
                <th className="sticky left-0 z-[1] bg-white dark:bg-slate-900 px-3 py-3 text-left text-xs font-semibold text-slate-400 uppercase min-w-[80px]">
                  Feature
                </th>
                {properties.map((p, i) => (
                  <th key={p.id} className="px-3 py-3 text-center min-w-[140px]">
                    <div className="w-12 h-12 rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 mx-auto mb-1.5">
                      {p.photo_urls[0] ? (
                        <img src={p.photo_urls[0]} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full" />
                      )}
                    </div>
                    <span className="text-xs font-bold text-slate-500">Option {i + 1}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.label} className="border-b border-slate-50 dark:border-slate-800/50">
                  <td className="sticky left-0 z-[1] bg-white dark:bg-slate-900 px-3 py-3 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
                    {row.label}
                  </td>
                  {properties.map((p) => {
                    const value = row.getValue(p);
                    const isBest =
                      row.label === 'Rent' && p.monthly_rent === cheapestRent && properties.length > 1 ||
                      row.label === 'Deposit' && p.security_deposit === lowestDeposit && properties.length > 1;
                    return (
                      <td
                        key={p.id}
                        className={`px-3 py-3 text-center text-sm ${
                          isBest
                            ? 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 font-bold'
                            : row.isHighlight
                            ? 'text-slate-800 dark:text-white font-semibold'
                            : 'text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {value}
                        {isBest && <span className="block text-[9px] text-emerald-500 font-bold mt-0.5">BEST</span>}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-4">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold text-sm btn-press"
          >
            Close Comparison
          </button>
        </div>
      </div>
    </div>
  );
}
