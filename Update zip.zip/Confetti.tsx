import { useState, useEffect, useMemo, type CSSProperties } from 'react';

interface ConfettiProps {
  onDone: () => void;
}

const COLORS = ['#0d9488', '#059669', '#0891b2', '#f59e0b', '#ec4899', '#3b82f6'];

export default function Confetti({ onDone }: ConfettiProps) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
      onDone();
    }, 2800);
    return () => clearTimeout(timer);
  }, [onDone]);

  const particles = useMemo(
    () =>
      Array.from({ length: 60 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 0.4,
        duration: 1.8 + Math.random() * 1.2,
        size: 6 + Math.random() * 8,
        color: COLORS[i % COLORS.length],
        rotation: Math.random() * 360,
        drift: (Math.random() - 0.5) * 120,
        round: i % 3 === 0,
      })),
    []
  );

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-[200] pointer-events-none overflow-hidden">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute top-0 confetti-particle"
          style={
            {
              left: `${p.left}%`,
              width: `${p.size}px`,
              height: `${p.size}px`,
              backgroundColor: p.color,
              animationDelay: `${p.delay}s`,
              animationDuration: `${p.duration}s`,
              borderRadius: p.round ? '50%' : '2px',
              '--confetti-drift': `${p.drift}px`,
              '--confetti-rotation': `${p.rotation}deg`,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}
