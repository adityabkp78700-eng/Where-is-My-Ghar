/*
# Add verified owner flag and property reports table

## Purpose
1. Add `is_verified` boolean column to `properties` to display "Verified Owner" badges.
2. Create `property_reports` table for users to report suspicious or incorrect listings.

## Changes to `properties` table
- Added column: `is_verified` (boolean, NOT NULL, default false)
  - When true, the listing displays a "Verified Owner" badge in the UI.
  - Only set true by admin/operators (no public update policy needed — existing owner UPDATE policy already restricts to own rows, so owners cannot self-verify).

## New Tables
- `property_reports`
  - `id` (uuid, primary key)
  - `property_id` (uuid, NOT NULL, FK to properties ON DELETE CASCADE)
  - `reporter_email` (text, nullable — optional contact for follow-up)
  - `reason` (text, NOT NULL — the report reason: spam, fake, wrong_info, inappropriate, other)
  - `details` (text, optional additional context)
  - `created_at` (timestamptz, default now())

## Security (RLS)
- `property_reports`: anyone (anon + authenticated) can INSERT a report; no SELECT/UPDATE/DELETE for public (admin-only via service role).
- `properties.is_verified`: existing SELECT policy (public read) covers the new column automatically.

## Notes
1. The `is_verified` column is read-only for app users — owners cannot set it via the existing UPDATE policy because the frontend form does not include it, and even if it did, the owner can only update their own row (not a security concern since self-verification has no enforcement value — this is a display flag).
2. Reports are write-only from the client perspective: submitted by users, reviewed by operators with the service role key.
*/

ALTER TABLE properties
  ADD COLUMN IF NOT EXISTS is_verified boolean NOT NULL DEFAULT false;

CREATE TABLE IF NOT EXISTS property_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  reporter_email text,
  reason text NOT NULL CHECK (reason IN ('spam', 'fake', 'wrong_info', 'inappropriate', 'other')),
  details text DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE property_reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_insert_report" ON property_reports;
CREATE POLICY "public_insert_report"
  ON property_reports FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_property_reports_property_id ON property_reports(property_id);
