import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { SearchX, RotateCcw, ShieldCheck, Heart, Clock, Building2, Map, Grid3x3, GitCompareArrows, Bell, BellRing, X, Trash2 } from 'lucide-react';
import { Property, PropertyCategory, BudgetFilter, SortOption, CATEGORY_LABELS, formatRent } from '@/lib/types';
import { supabase } from '@/lib/supabase';
import { useSaved } from '@/context/SavedContext';
import { useToast } from '@/context/ToastContext';
import SearchBar from '@/components/SearchBar';
import CategoryChips from '@/components/CategoryChips';
import BudgetSortBar from '@/components/BudgetSortBar';
import PropertyCard from '@/components/PropertyCard';
import SkeletonCard from '@/components/SkeletonCard';
import AdSlot from '@/components/AdSlot';
import MapView from '@/components/MapView';
import CompareBar, { CompareSheet } from '@/components/CompareBar';

const COMPARE_MAX = 3;

interface GuestViewProps {
  onOpenDetail: (p: Property) => void;
  onOpenPhoto: (photos: string[], index: number) => void;
  onCallOwner: (p: Property) => void;
  onWhatsAppOwner: (p: Property) => void;
  onReport: (p: Property) => void;
}

type ViewMode = 'grid' | 'map';

export default function GuestView({ onOpenDetail, onOpenPhoto, onCallOwner, onWhatsAppOwner, onReport }: GuestViewProps) {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<PropertyCategory | 'all'>('all');
  const [budget, setBudget] = useState<BudgetFilter>('all');
  const [sort, setSort] = useState<SortOption>('default');
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [heroSlide, setHeroSlide] = useState(0);
  const [showSavedOnly, setShowSavedOnly] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [compareMode, setCompareMode] = useState(false);
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [showCompareSheet, setShowCompareSheet] = useState(false);
  const [showAlertManager, setShowAlertManager] = useState(false);
  const touchStartX = useRef<number | null>(null);
  const { savedProperties, recentlyViewed, searchAlerts, addSearchAlert, removeSearchAlert } = useSaved();
  const { showToast } = useToast();

  const heroSlides = [
    { title: 'Ab dalal ki koi zaroorat nahi!', subtitle: 'Direct owner se baat karein — zero brokerage, zero hassle.' },
    { title: 'Apna perfect ghar, bina extra charge.', subtitle: 'Verified locations mein rooms, hostels aur flats dhoondhiye.' },
    { title: 'Rent par ghar dhoondhna ab easy.', subtitle: 'City, locality ya landmark se apna next home discover karein.' },
    { title: 'Bharat bhar mein, ghar ke kareeb.', subtitle: 'Simple search, clear rent aur seedhi owner se baat.' },
  ];

  useEffect(() => {
    const timer = window.setInterval(() => {
      setHeroSlide((current) => (current + 1) % heroSlides.length);
    }, 4200);
    return () => window.clearInterval(timer);
  }, [heroSlides.length]);

  const moveHero = (direction: 1 | -1) => {
    setHeroSlide((current) => (current + direction + heroSlides.length) % heroSlides.length);
  };

  const fetchProperties = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      let query = supabase.from('properties').select('*').order('created_at', { ascending: false });
      if (category !== 'all') {
        query = query.eq('category', category);
      }

      const { data, error: err } = await query;
      if (err) throw err;

      let filtered: Property[] = data || [];

      if (budget === 'under5000') filtered = filtered.filter((p) => p.monthly_rent < 5000);
      else if (budget === '5000to10000') filtered = filtered.filter((p) => p.monthly_rent >= 5000 && p.monthly_rent <= 10000);
      else if (budget === 'above10000') filtered = filtered.filter((p) => p.monthly_rent > 10000);

      if (search.trim()) {
        const q = search.toLowerCase().trim();
        filtered = filtered.filter((p) =>
          p.city.toLowerCase().includes(q) ||
          p.state.toLowerCase().includes(q) ||
          p.landmark.toLowerCase().includes(q) ||
          p.pincode.includes(q) ||
          p.address.toLowerCase().includes(q)
        );
      }

      if (sort === 'rentLowHigh') {
        filtered.sort((a, b) => a.monthly_rent - b.monthly_rent);
      }

      setProperties(filtered);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load properties');
    } finally {
      setLoading(false);
    }
  }, [category, budget, search, sort]);

  useEffect(() => {
    const timer = setTimeout(fetchProperties, 300);
    return () => clearTimeout(timer);
  }, [fetchProperties]);

  // Search alerts: check for matches when properties load
  const alertedRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    if (loading || properties.length === 0 || searchAlerts.length === 0) return;

    for (const alert of searchAlerts) {
      if (alertedRef.current.has(alert.id)) continue;
      const matches = properties.filter((p) => {
        const cityMatch = p.city.toLowerCase().includes(alert.city.toLowerCase());
        const budgetMatch =
          alert.budget === 'all' ||
          (alert.budget === 'under5000' && p.monthly_rent < 5000) ||
          (alert.budget === '5000to10000' && p.monthly_rent >= 5000 && p.monthly_rent <= 10000) ||
          (alert.budget === 'above10000' && p.monthly_rent > 10000);
        const categoryMatch = alert.category === 'all' || p.category === alert.category;
        return cityMatch && budgetMatch && categoryMatch;
      });
      if (matches.length > 0) {
        showToast(`Search Alert: ${matches.length} new listing(s) matching "${alert.city}" found!`, 'success');
        alertedRef.current.add(alert.id);
      }
    }
  }, [loading, properties, searchAlerts, showToast]);

  const hasFilters = search || category !== 'all' || budget !== 'all' || sort !== 'default';

  const resetFilters = () => {
    setSearch('');
    setCategory('all');
    setBudget('all');
    setSort('default');
    setShowSavedOnly(false);
  };

  const displayedProperties = useMemo(() => {
    if (showSavedOnly) {
      return savedProperties;
    }
    return properties;
  }, [showSavedOnly, savedProperties, properties]);

  const toggleCompare = (p: Property) => {
    setCompareIds((prev) => {
      if (prev.includes(p.id)) {
        return prev.filter((id) => id !== p.id);
      }
      if (prev.length >= COMPARE_MAX) {
        showToast(`You can compare up to ${COMPARE_MAX} properties`, 'error');
        return prev;
      }
      return [...prev, p.id];
    });
  };

  const compareProperties = useMemo(
    () => compareIds.map((id) => properties.find((p) => p.id === id)).filter(Boolean) as Property[],
    [compareIds, properties]
  );

  const handleSaveAlert = () => {
    if (!search.trim() && category === 'all' && budget === 'all') {
      showToast('Set at least one filter to save an alert', 'error');
      return;
    }
    addSearchAlert({
      city: search.trim() || 'All cities',
      budget,
      category,
    });
    showToast('Search alert saved! We will notify you of matches.', 'success');
  };

  return (
    <div className="space-y-4">
      <section
        className="relative overflow-hidden rounded-[28px] bg-gradient-to-br from-[#0876df] via-[#078fa9] to-[#00a651] px-6 pt-6 pb-6 text-white shadow-[0_18px_40px_rgba(0,131,177,0.18)]"
        onTouchStart={(event) => { touchStartX.current = event.touches[0].clientX; }}
        onTouchEnd={(event) => {
          if (touchStartX.current === null) return;
          const distance = event.changedTouches[0].clientX - touchStartX.current;
          if (Math.abs(distance) > 45) moveHero(distance < 0 ? 1 : -1);
          touchStartX.current = null;
        }}
      >
        <div className="absolute -right-16 -top-20 h-48 w-48 rounded-full bg-white/10 blur-2xl" />
        <div className="relative">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div key={heroSlide} className="hero-copy-enter">
                <h2 className="max-w-[300px] text-[28px] font-extrabold leading-[1.1] tracking-[-0.8px]">
                  {heroSlides[heroSlide].title}
                </h2>
                <p className="mt-3 max-w-[330px] text-[15px] font-medium leading-[1.4] text-white/90">
                  {heroSlides[heroSlide].subtitle}
                </p>
              </div>
            </div>
            <div className="hidden rounded-2xl bg-white/15 p-3 sm:block">
              <ShieldCheck className="h-7 w-7 text-white" />
            </div>
          </div>
          <div className="mt-2.5 flex items-center gap-1.5" aria-label="Hero slides">
            {heroSlides.map((slide, index) => (
              <button
                key={slide.title}
                onClick={() => setHeroSlide(index)}
                aria-label={`Show slide ${index + 1}`}
                className={`h-1.5 rounded-full transition-all duration-200 ${index === heroSlide ? 'w-9 bg-white' : 'w-1.5 bg-white/45'}`}
              />
            ))}
          </div>
          <div className="mt-6">
            <SearchBar value={search} onChange={setSearch} onVoiceResult={setSearch} />
          </div>
        </div>
      </section>

      <CategoryChips selected={category} onSelect={setCategory} />

      {/* Saved & Recently Viewed sections (only when no active search) */}
      {!hasFilters && !loading && !showSavedOnly && (
        <SavedAndRecentSections
          savedProperties={savedProperties}
          recentlyViewed={recentlyViewed}
          onOpenDetail={onOpenDetail}
          onSeeAllSaved={() => setShowSavedOnly(true)}
        />
      )}

      {/* Search Alerts Manager */}
      {showAlertManager && (
        <SearchAlertManager
          alerts={searchAlerts}
          onRemove={removeSearchAlert}
          onClose={() => setShowAlertManager(false)}
        />
      )}

      <BudgetSortBar budget={budget} onBudgetChange={setBudget} sort={sort} onSortChange={setSort} />

      {/* Action toolbar: view toggle, compare, alerts */}
      <div className="flex items-center gap-2 px-1">
        <p className="text-[16px] font-medium tracking-[-0.2px] text-slate-500 dark:text-slate-400 flex-1">
          {loading ? 'Finding homes...' : showSavedOnly ? `${savedProperties.length} saved properties` : `${properties.length} properties found`}
        </p>
        <button
          onClick={() => setShowAlertManager((v) => !v)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 btn-press"
          aria-label="Search alerts"
        >
          {searchAlerts.length > 0 ? <BellRing className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" /> : <Bell className="w-3.5 h-3.5" />}
          <span className="hidden sm:inline">Alerts</span>
          {searchAlerts.length > 0 && (
            <span className="w-4 h-4 rounded-full bg-teal-500 text-white text-[9px] font-bold flex items-center justify-center">
              {searchAlerts.length}
            </span>
          )}
        </button>
        <button
          onClick={() => {
            setCompareMode((v) => !v);
            if (compareMode) setCompareIds([]);
          }}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold btn-press transition-colors ${
            compareMode
              ? 'bg-teal-50 dark:bg-teal-900/30 border-teal-300 dark:border-teal-700 text-teal-600 dark:text-teal-400'
              : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
          }`}
          aria-label="Compare mode"
        >
          <GitCompareArrows className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Compare</span>
          {compareIds.length > 0 && (
            <span className="w-4 h-4 rounded-full bg-teal-500 text-white text-[9px] font-bold flex items-center justify-center">
              {compareIds.length}
            </span>
          )}
        </button>
        <div className="flex rounded-lg border border-slate-200 dark:border-slate-700 overflow-hidden">
          <button
            onClick={() => setViewMode('grid')}
            className={`flex items-center justify-center w-9 h-8 transition-colors ${
              viewMode === 'grid' ? 'bg-teal-50 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400' : 'bg-white dark:bg-slate-800 text-slate-400'
            }`}
            aria-label="Grid view"
          >
            <Grid3x3 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setViewMode('map')}
            className={`flex items-center justify-center w-9 h-8 transition-colors ${
              viewMode === 'map' ? 'bg-teal-50 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400' : 'bg-white dark:bg-slate-800 text-slate-400'
            }`}
            aria-label="Map view"
          >
            <Map className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Save alert button when filters are active */}
      {hasFilters && !loading && (
        <button
          onClick={handleSaveAlert}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-400 text-xs font-semibold btn-press w-full"
        >
          <Bell className="w-3.5 h-3.5" />
          Save this search as an alert — get notified when new properties match
        </button>
      )}

      {/* Results */}
      {loading ? (
        <div className="grid grid-cols-1 gap-3">
          {Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      ) : error ? (
        <div className="text-center py-12">
          <p className="text-sm text-red-500 mb-2">{error}</p>
          <button onClick={fetchProperties} className="text-sm text-teal-600 font-semibold">Try again</button>
        </div>
      ) : displayedProperties.length === 0 ? (
        <div className="text-center py-16 flex flex-col items-center gap-3">
          <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
            <SearchX className="w-8 h-8 text-slate-400" />
          </div>
          {showSavedOnly ? (
            <>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">No saved properties yet</p>
              <p className="text-xs text-slate-400 max-w-[280px]">Tap the heart icon on any listing to save it for later.</p>
              <button onClick={() => setShowSavedOnly(false)} className="text-sm text-teal-600 font-semibold mt-1">Browse all properties</button>
            </>
          ) : hasFilters ? (
            <>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">No properties match your filters</p>
              <button onClick={resetFilters} className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-50 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400 text-sm font-semibold btn-press">
                <RotateCcw className="w-3.5 h-3.5" /> Reset Filters
              </button>
            </>
          ) : (
            <>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">No properties listed in this area yet</p>
              <p className="text-xs text-slate-400 max-w-[280px]">Try another city or locality to find available homes.</p>
            </>
          )}
        </div>
      ) : viewMode === 'map' ? (
        <MapView properties={displayedProperties} onSelect={onOpenDetail} />
      ) : (
        <div className="space-y-3">
          {showSavedOnly && (
            <button
              onClick={() => setShowSavedOnly(false)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-semibold btn-press"
            >
              <X className="w-3.5 h-3.5" /> Back to all properties
            </button>
          )}
          {displayedProperties.map((p, i) => (
            <div key={p.id}>
              <PropertyCard
                property={p}
                onOpenDetail={onOpenDetail}
                onOpenPhoto={onOpenPhoto}
                onCallOwner={onCallOwner}
                onWhatsAppOwner={onWhatsAppOwner}
                compareMode={compareMode}
                compareSelected={compareIds.includes(p.id)}
                onToggleCompare={toggleCompare}
              />
              {(i + 1) % 5 === 0 && <AdSlot variant="feed" />}
            </div>
          ))}
        </div>
      )}

      {/* Compare bar */}
      <CompareBar
        properties={compareProperties}
        onRemove={(id) => setCompareIds((prev) => prev.filter((x) => x !== id))}
        onClear={() => setCompareIds([])}
        onCompare={() => setShowCompareSheet(true)}
        max={COMPARE_MAX}
      />

      {/* Compare sheet */}
      {showCompareSheet && (
        <CompareSheet
          properties={compareProperties}
          onClose={() => setShowCompareSheet(false)}
        />
      )}
    </div>
  );
}

function SavedAndRecentSections({ savedProperties, recentlyViewed, onOpenDetail, onSeeAllSaved }: {
  savedProperties: Property[];
  recentlyViewed: Property[];
  onOpenDetail: (p: Property) => void;
  onSeeAllSaved: () => void;
}) {
  if (savedProperties.length === 0 && recentlyViewed.length === 0) return null;

  return (
    <div className="space-y-4">
      {savedProperties.length > 0 && (
        <section>
          <div className="flex items-center gap-2 px-1 mb-2">
            <Heart className="w-4 h-4 text-rose-500" fill="currentColor" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">Saved</h3>
            <span className="text-xs text-slate-400">{savedProperties.length}</span>
            {savedProperties.length > 5 && (
              <button onClick={onSeeAllSaved} className="ml-auto text-xs font-semibold text-teal-600 dark:text-teal-400">
                See all
              </button>
            )}
          </div>
          <div className="flex gap-3 overflow-x-auto no-scrollbar saved-scroll pb-1 -mx-1 px-1">
            {savedProperties.slice(0, 5).map((p) => (
              <MiniPropertyCard key={p.id} property={p} onClick={() => onOpenDetail(p)} />
            ))}
          </div>
        </section>
      )}

      {recentlyViewed.length > 0 && (
        <section>
          <div className="flex items-center gap-2 px-1 mb-2">
            <Clock className="w-4 h-4 text-slate-400" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">Recently Viewed</h3>
          </div>
          <div className="flex gap-3 overflow-x-auto no-scrollbar saved-scroll pb-1 -mx-1 px-1">
            {recentlyViewed.map((p) => (
              <MiniPropertyCard key={p.id} property={p} onClick={() => onOpenDetail(p)} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function MiniPropertyCard({ property, onClick }: { property: Property; onClick: () => void }) {
  const cover = property.photo_urls?.[0];
  return (
    <button
      onClick={onClick}
      className="flex-shrink-0 w-36 rounded-2xl overflow-hidden border border-slate-200/80 bg-white dark:border-slate-700 dark:bg-slate-800 text-left card-tap fade-in-up"
    >
      <div className="h-20 bg-slate-100 dark:bg-slate-700 overflow-hidden">
        {cover ? (
          <img src={cover} alt="" className="w-full h-full object-cover" loading="lazy" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Building2 className="w-6 h-6 text-slate-300 dark:text-slate-600" />
          </div>
        )}
      </div>
      <div className="p-2">
        <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{formatRent(property.monthly_rent)}/mo</p>
        <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">{CATEGORY_LABELS[property.category]} · {property.city}</p>
      </div>
    </button>
  );
}

function SearchAlertManager({ alerts, onRemove, onClose }: {
  alerts: import('@/lib/types').SearchAlert[];
  onRemove: (id: string) => void;
  onClose: () => void;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4 space-y-3 sheet-enter">
      <div className="flex items-center gap-2">
        <BellRing className="w-4 h-4 text-teal-600 dark:text-teal-400" />
        <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">Your Search Alerts</h3>
        <button onClick={onClose} className="ml-auto w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
          <X className="w-3.5 h-3.5 text-slate-400" />
        </button>
      </div>
      {alerts.length === 0 ? (
        <p className="text-xs text-slate-400 text-center py-3">
          No alerts saved yet. Set filters and tap "Save this search as an alert" to get notified of new matches.
        </p>
      ) : (
        <div className="space-y-2">
          {alerts.map((alert) => (
            <div key={alert.id} className="flex items-center gap-2 rounded-xl bg-slate-50 dark:bg-slate-700/50 p-2.5">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{alert.city}</p>
                <p className="text-[10px] text-slate-400">
                  {alert.category === 'all' ? 'All types' : CATEGORY_LABELS[alert.category]} ·{' '}
                  {alert.budget === 'all' ? 'Any budget' : alert.budget === 'under5000' ? 'Under Rs.5K' : alert.budget === '5000to10000' ? 'Rs.5K-Rs.10K' : 'Above Rs.10K'}
                </p>
              </div>
              <button
                onClick={() => onRemove(alert.id)}
                className="w-7 h-7 rounded-lg bg-red-50 dark:bg-red-900/30 flex items-center justify-center btn-press flex-shrink-0"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-500" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
