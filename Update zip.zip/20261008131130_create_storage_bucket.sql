/*
# Create property-photos storage bucket with RLS policies

## Purpose
Storage bucket for property listing photos. Max 3 photos per listing.
- Authenticated owners can upload photos
- Public can view photos (for browsing listings)
- Owners can delete only their own photos (path starts with their user_id)

## Storage Policies
- SELECT (read): Public — anyone can view property photos
- INSERT (upload): Authenticated only
- UPDATE: Authenticated only
- DELETE: Authenticated only, files must be under their user_id folder
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('property-photos', 'property-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Public read access for property photos
DROP POLICY IF EXISTS "public_read_property_photos" ON storage.objects;
CREATE POLICY "public_read_property_photos"
  ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'property-photos');

-- Authenticated users can upload to property-photos
DROP POLICY IF EXISTS "auth_upload_property_photos" ON storage.objects;
CREATE POLICY "auth_upload_property_photos"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'property-photos');

-- Authenticated users can update their own photos
DROP POLICY IF EXISTS "auth_update_property_photos" ON storage.objects;
CREATE POLICY "auth_update_property_photos"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'property-photos' AND owner = auth.uid())
  WITH CHECK (bucket_id = 'property-photos');

-- Authenticated users can delete their own photos
DROP POLICY IF EXISTS "auth_delete_property_photos" ON storage.objects;
CREATE POLICY "auth_delete_property_photos"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'property-photos' AND owner = auth.uid());