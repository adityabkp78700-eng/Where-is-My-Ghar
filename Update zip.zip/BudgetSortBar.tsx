import { BudgetFilter, SortOption } from '@/lib/types';

interface BudgetSortBarProps {
  budget: BudgetFilter;
  onBudgetChange: (b: BudgetFilter) => void;
  sort: SortOption;
  onSortChange: (s: SortOption) => void;
}

const BUDGET_OPTIONS: { value: BudgetFilter; label: string }[] = [
  { value: 'all', label: 'All Budgets' },
  { value: 'under5000', label: 'Under ₹5K' },
  { value: '5000to10000', label: '₹5K–₹10K' },
  { value: 'above10000', label: '₹10K+' },
];

export default function BudgetSortBar({ budget, onBudgetChange, sort, onSortChange }: BudgetSortBarProps) {
  return (
    <div className="flex items-center gap-2 overflow-x-auto no-scrollbar -mx-4 px-4 gpu-scroll">
      <select
        value={budget}
        onChange={(e) => onBudgetChange(e.target.value as BudgetFilter)}
        className="flex-shrink-0 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 outline-none cursor-pointer"
      >
        {BUDGET_OPTIONS.map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>

      <select
        value={sort}
        onChange={(e) => onSortChange(e.target.value as SortOption)}
        className="flex-shrink-0 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 outline-none cursor-pointer"
      >
        <option value="default">Default Sort</option>
        <option value="rentLowHigh">Rent: Low to High</option>
      </select>
    </div>
  );
}
