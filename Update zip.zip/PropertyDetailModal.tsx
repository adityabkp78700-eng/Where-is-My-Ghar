import { useEffect, useState } from 'react';
import { X, Phone, MessageCircle, MapPin, Navigation, MapPinned, Building, Route, Landmark, Crosshair, Heart, Share2, BadgeCheck, Flag } from 'lucide-react';
import { Property, CATEGORY_LABELS, AMENITY_MAP, formatRent, timeAgo } from '@/lib/types';
import { useSaved } from '@/context/SavedContext';
import { useToast } from '@/context/ToastContext';

interface PropertyDetailModalProps {
  property: Property | null;
  onClose: () => void;
  onOpenPhoto: (photos: string[], index: number) => void;
  onCallOwner: (p: Property) => void;
  onWhatsAppOwner: (p: Property) => void;
  onReport?: (p: Property) => void;
}

export default function PropertyDetailModal({ property, onClose, onOpenPhoto, onCallOwner, onWhatsAppOwner, onReport }: PropertyDetailModalProps) {
  const [showSheet, setShowSheet] = useState(false);
  const [currentPhoto, setCurrentPhoto] = useState(0);
  const { isSaved, toggleSave } = useSaved();
  const { showToast } = useToast();
  const saved = property ? isSaved(property.id) : false;

  useEffect(() => {
    if (property) {
      setShowSheet(true);
      setCurrentPhoto(0);
    } else {
      setShowSheet(false);
    }
  }, [property]);

  useEffect(() => {
    if (property) {
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = '';
      };
    }
  }, [property]);

  if (!property) return null;

  const hasCoords = property.latitude != null && property.longitude != null;
  const mapEmbedUrl = hasCoords
    ? `https://www.google.com/maps?q=${property.latitude},${property.longitude}&z=15&output=embed`
    : `https://www.google.com/maps?q=${encodeURIComponent(`${property.address}, ${property.city}, ${property.state} ${property.pincode}`)}&z=15&output=embed`;

  const navigateUrl = hasCoords
    ? `https://www.google.com/maps/dir/?api=1&destination=${property.latitude},${property.longitude}`
    : `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${property.address}, ${property.city}, ${property.state} ${property.pincode}`)}`;

  const handleShare = async () => {
    const baseUrl = window.location.origin;
    const shareUrl = `${baseUrl}/property/${property.id}`;
    const text = `Check out this ${CATEGORY_LABELS[property.category]} for rent in ${property.city} — ${formatRent(property.monthly_rent)}/month on Where Is My Ghar: ${shareUrl}`;
    if (navigator.share) {
      try { await navigator.share({ text, url: shareUrl }); return; } catch { /* user cancelled share */ }
    }
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleSave = () => {
    if (!property) return;
    toggleSave(property);
    showToast(saved ? 'Removed from saved' : 'Added to saved', 'success');
    navigator.vibrate?.(8);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm backdrop-fade"
        onClick={onClose}
      />

      {/* Sheet */}
      <div
        className={`relative w-full sm:max-w-lg max-h-[92vh] overflow-y-auto bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl gpu-scroll no-scrollbar ${
          showSheet ? 'sheet-enter' : 'sheet-exit'
        }`}
      >
        {/* Grab handle */}
        <div className="sticky top-0 z-10 flex justify-center pt-3 pb-2 bg-white dark:bg-slate-900">
          <div className="w-10 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700" />
          <button
            onClick={onClose}
            className="absolute right-3 top-2.5 w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center btn-press"
          >
            <X className="w-4 h-4 text-slate-500" />
          </button>
        </div>

        {/* Photo gallery */}
        {property.photo_urls.length > 0 ? (
          <div className="px-4">
            <div className="relative h-56 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800">
              <button
                onClick={() => onOpenPhoto(property.photo_urls, currentPhoto)}
                className="relative block h-full w-full cursor-zoom-in text-left"
                aria-label="Open property photos"
              >
                <img
                  src={property.photo_urls[currentPhoto]}
                  alt={`${CATEGORY_LABELS[property.category]} photo ${currentPhoto + 1}`}
                  className="w-full h-full object-cover"
                />
                <span className="absolute bottom-3 right-3 rounded-full bg-slate-950/65 px-2.5 py-1.5 text-[10px] font-semibold text-white backdrop-blur-sm">
                  🔍 Tap to Zoom
                </span>
              </button>
              {property.photo_urls.length > 1 && (
                <>
                  <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5">
                    {property.photo_urls.map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setCurrentPhoto(i)}
                        className={`w-2 h-2 rounded-full transition-all ${
                          i === currentPhoto ? 'bg-white w-5' : 'bg-white/50'
                        }`}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        ) : (
          <div className="px-4">
            <div className="h-40 rounded-2xl bg-gradient-to-br from-teal-100 to-emerald-100 dark:from-teal-900/30 dark:to-emerald-900/30 flex items-center justify-center">
              <Building className="w-16 h-16 text-teal-300 dark:text-teal-600" />
            </div>
          </div>
        )}

        <div className="p-4 space-y-4">
          {/* Rent + Status */}
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-bold text-slate-900 dark:text-white">{formatRent(property.monthly_rent)}</span>
                <span className="text-sm text-slate-500">/month</span>
              </div>
              <p className="text-sm text-slate-500 mt-0.5">Security Deposit: {formatRent(property.security_deposit)}</p>
            </div>
            <span
              className={`px-3 py-1.5 rounded-full text-xs font-bold ${
                property.status === 'available'
                  ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400'
                  : 'bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400'
              }`}
            >
              {property.status === 'available' ? 'Available' : 'Rented Out'}
            </span>
          </div>

          {/* Category + Verified */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-sm font-semibold text-slate-700 dark:text-slate-300">
              {CATEGORY_LABELS[property.category]}
            </span>
            {property.is_verified && (
              <span className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs font-bold">
                <BadgeCheck className="w-3.5 h-3.5" />
                Verified Owner
              </span>
            )}
            <span className="text-xs text-slate-400 ml-auto">{timeAgo(property.created_at)}</span>
          </div>

          {/* Amenities */}
          {property.amenities.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Amenities</h3>
              <div className="grid grid-cols-4 gap-2">
                {property.amenities.map((id) => {
                  const a = AMENITY_MAP[id];
                  if (!a) return null;
                  return (
                    <div key={id} className="flex flex-col items-center gap-1 p-2 rounded-xl bg-slate-50 dark:bg-slate-800">
                      <span className="text-xl">{a.icon}</span>
                      <span className="text-[10px] font-medium text-slate-600 dark:text-slate-400 text-center">{a.label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Address Card */}
          <div>
            <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Address Details</h3>
            <div className="rounded-2xl border border-slate-200 dark:border-slate-700 p-3 space-y-2.5">
              <div className="flex items-start gap-2.5">
                <Route className="w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] font-semibold text-slate-400 uppercase">Street Address</p>
                  <p className="text-sm text-slate-700 dark:text-slate-200">{property.address}</p>
                </div>
              </div>
              {property.landmark && (
                <div className="flex items-start gap-2.5">
                  <Landmark className="w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-semibold text-slate-400 uppercase">Nearby Landmark</p>
                    <p className="text-sm text-slate-700 dark:text-slate-200">{property.landmark}</p>
                  </div>
                </div>
              )}
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] font-semibold text-slate-400 uppercase">Locality & City</p>
                  <p className="text-sm text-slate-700 dark:text-slate-200">{property.city}, {property.state}</p>
                </div>
              </div>
              {property.pincode && (
                <div className="flex items-start gap-2.5">
                  <MapPinned className="w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-semibold text-slate-400 uppercase">Pincode</p>
                    <p className="text-sm text-slate-700 dark:text-slate-200">{property.pincode}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Interactive Map */}
          <div>
            <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Location Map</h3>
            <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 h-48 bg-slate-100 dark:bg-slate-800">
              <iframe
                src={mapEmbedUrl}
                className="w-full h-full"
                style={{ border: 0 }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Property location map"
              />
              {/* Custom pin overlay */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-full pointer-events-none z-10">
                <div className="relative">
                  <MapPin className="w-8 h-8 text-teal-600 drop-shadow-lg" fill="#0d9488" fillOpacity={0.3} strokeWidth={2.5} />
                </div>
              </div>
              {!hasCoords && (
                <div className="absolute bottom-2 left-2 right-2 bg-amber-50/90 dark:bg-amber-950/80 backdrop-blur rounded-lg px-3 py-1.5 text-xs text-amber-700 dark:text-amber-300 flex items-center gap-1.5">
                  <Crosshair className="w-3.5 h-3.5 flex-shrink-0" />
                  Approximate location based on address
                </div>
              )}
            </div>
            <button
              onClick={() => window.open(navigateUrl, '_blank')}
              className="w-full mt-2 flex items-center justify-center gap-2 py-3 rounded-xl gradient-teal-emerald text-white font-semibold text-sm btn-press shadow-md shadow-teal-500/20"
            >
              <Navigation className="w-4 h-4" />
              Navigate with Google Maps
            </button>
          </div>

          {/* Report listing + Owner action buttons */}
          {onReport && (
            <button
              onClick={() => onReport(property)}
              className="w-full flex items-center justify-center gap-1.5 py-2 rounded-xl text-red-400 dark:text-red-400 text-xs font-semibold hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors btn-press"
            >
              <Flag className="w-3.5 h-3.5" />
              Report this listing
            </button>
          )}

          <div className="flex gap-2 pt-1">
            <button
              onClick={() => onCallOwner(property)}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-teal-500 text-white font-semibold text-sm btn-press hover:bg-teal-600 transition-colors"
            >
              <Phone className="w-4 h-4" />
              Call Owner
            </button>
            <button
              onClick={() => onWhatsAppOwner(property)}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-green-500 text-white font-semibold text-sm btn-press hover:bg-green-600 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp
            </button>
            <button
              onClick={handleSave}
              className={`flex items-center justify-center w-12 py-3 rounded-xl btn-press transition-colors ${saved ? 'bg-rose-100 dark:bg-rose-900/30 text-rose-500' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}
              aria-label={saved ? 'Remove from saved' : 'Save property'}
            >
              <Heart className="w-4 h-4" fill={saved ? 'currentColor' : 'none'} strokeWidth={2.2} />
            </button>
            <button
              onClick={handleShare}
              className="flex items-center justify-center w-12 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 btn-press"
              aria-label="Share"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
