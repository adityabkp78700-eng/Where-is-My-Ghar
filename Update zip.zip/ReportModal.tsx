import { useState, useEffect } from 'react';
import { X, Flag, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/context/ToastContext';
import type { Property, ReportReason } from '@/lib/types';

interface ReportModalProps {
  property: Property | null;
  onClose: () => void;
}

const REASONS: { value: ReportReason; label: string }[] = [
  { value: 'spam', label: 'Spam or重复 listing' },
  { value: 'fake', label: 'Fake or scam listing' },
  { value: 'wrong_info', label: 'Wrong information' },
  { value: 'inappropriate', label: 'Inappropriate content' },
  { value: 'other', label: 'Other reason' },
];

export default function ReportModal({ property, onClose }: ReportModalProps) {
  const [reason, setReason] = useState<ReportReason | ''>('');
  const [details, setDetails] = useState('');
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const { showToast } = useToast();

  useEffect(() => {
    if (property) {
      setReason('');
      setDetails('');
      setBusy(false);
    }
  }, [property]);

  useEffect(() => {
    if (property) {
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = '';
      };
    }
  }, [property]);

  if (!property) return null;

  const handleSubmit = async () => {
    if (!reason) {
      showToast('Please select a reason', 'error');
      return;
    }
    setBusy(true);
    const { error } = await supabase.from('property_reports').insert({
      property_id: property.id,
      reason,
      details: details.trim(),
      reporter_email: email.trim() || null,
    });

    if (error) {
      showToast('Failed to submit report. Try again.', 'error');
    } else {
      showToast('Report submitted. Thank you!', 'success');
      onClose();
    }
    setBusy(false);
  };

  return (
    <div className="fixed inset-0 z-[75] flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm backdrop-fade" onClick={onClose} />

      <div className="relative w-full sm:max-w-md max-h-[85vh] overflow-y-auto bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl gpu-scroll no-scrollbar sheet-enter">
        <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-3 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Flag className="w-5 h-5 text-red-500" />
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Report Listing</h2>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center btn-press">
            <X className="w-4 h-4 text-slate-500" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          <div className="rounded-xl bg-slate-50 dark:bg-slate-800 p-3">
            <p className="text-xs font-semibold text-slate-400 uppercase">Listing</p>
            <p className="text-sm text-slate-700 dark:text-slate-200 mt-0.5">
              {property.category} in {property.city}, {property.state} — Rs.{property.monthly_rent}/mo
            </p>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2 block">Reason for reporting</label>
            <div className="space-y-2">
              {REASONS.map((r) => (
                <button
                  key={r.value}
                  onClick={() => setReason(r.value)}
                  className={`w-full text-left flex items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-medium border transition-all btn-press ${
                    reason === r.value
                      ? 'border-red-300 bg-red-50 text-red-700 dark:border-red-700 dark:bg-red-950/30 dark:text-red-300'
                      : 'border-slate-200 bg-white text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full border-2 flex-shrink-0 ${reason === r.value ? 'border-red-500 bg-red-500' : 'border-slate-300 dark:border-slate-600'}`} />
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Additional details (optional)</label>
            <textarea
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              placeholder="Tell us more about the issue..."
              rows={3}
              className="w-full bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-2.5 text-sm border border-slate-200 dark:border-slate-700 outline-none focus:border-red-400 transition-colors text-slate-800 dark:text-slate-100 resize-none"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Your email (optional)</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="For follow-up updates"
              className="w-full bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-2.5 text-sm border border-slate-200 dark:border-slate-700 outline-none focus:border-red-400 transition-colors text-slate-800 dark:text-slate-100"
            />
          </div>

          <button
            onClick={handleSubmit}
            disabled={busy}
            className="w-full py-3.5 rounded-xl bg-red-500 text-white font-semibold text-sm btn-press shadow-md shadow-red-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {busy ? <><Loader2 className="w-4 h-4 animate-spin" /> Submitting...</> : 'Submit Report'}
          </button>

          <p className="text-center text-xs text-slate-400">
            Reports are reviewed by our team and kept confidential.
          </p>
        </div>
      </div>
    </div>
  );
}
