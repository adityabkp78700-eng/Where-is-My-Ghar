export type PropertyCategory = 'hostel' | 'room' | 'flat';
export type PropertyStatus = 'available' | 'rented';
export type AppMode = 'guest' | 'owner';
export type ThemeMode = 'light' | 'dark' | 'system';
export type BudgetFilter = 'all' | 'under5000' | '5000to10000' | 'above10000';
export type SortOption = 'default' | 'rentLowHigh';

export interface Property {
  id: string;
  user_id: string;
  category: PropertyCategory;
  monthly_rent: number;
  security_deposit: number;
  city: string;
  state: string;
  address: string;
  landmark: string;
  pincode: string;
  owner_phone: string;
  latitude: number | null;
  longitude: number | null;
  amenities: string[];
  photo_urls: string[];
  status: PropertyStatus;
  is_verified: boolean;
  last_activity_at: string;
  rented_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface PropertyInput {
  category: PropertyCategory;
  monthly_rent: number;
  security_deposit: number;
  city: string;
  state: string;
  address: string;
  landmark: string;
  pincode: string;
  owner_phone: string;
  latitude: number | null;
  longitude: number | null;
  amenities: string[];
  photo_urls: string[];
}

export const CATEGORY_LABELS: Record<PropertyCategory, string> = {
  hostel: 'Hostel',
  room: 'Rental Room',
  flat: 'Flat',
};

export const CATEGORY_ICONS: Record<PropertyCategory, string> = {
  hostel: '🏨',
  room: '🛏️',
  flat: '🏢',
};

export const AMENITY_LIST: { id: string; label: string; icon: string }[] = [
  { id: 'wifi', label: 'WiFi', icon: '📶' },
  { id: 'ro_water', label: 'RO Water', icon: '💧' },
  { id: 'power_backup', label: 'Power Backup', icon: '🔋' },
  { id: 'parking', label: 'Parking', icon: '🛵' },
  { id: 'ac', label: 'AC/Cooler', icon: '❄️' },
  { id: 'washroom', label: 'Attached Washroom', icon: '🚿' },
  { id: 'mess', label: 'Mess/Food', icon: '🍽️' },
  { id: 'maid', label: 'Maid/Cleaning', icon: '🧹' },
];

export const AMENITY_MAP = AMENITY_LIST.reduce((acc, a) => {
  acc[a.id] = a;
  return acc;
}, {} as Record<string, { id: string; label: string; icon: string }>);

export type ReportReason = 'spam' | 'fake' | 'wrong_info' | 'inappropriate' | 'other';

export interface SearchAlert {
  id: string;
  city: string;
  budget: BudgetFilter;
  category: PropertyCategory | 'all';
  created_at: string;
}

export const SHOW_ADS = false;

// Re-export utility functions for convenient imports
export { formatRent, timeAgo, isInactive } from '@/lib/imageUtils';
