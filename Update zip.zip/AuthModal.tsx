import { useState, useEffect } from 'react';
import { X, Mail, Lock, MapPin, Home } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  title?: string;
}

export default function AuthModal({ open, onClose, onSuccess, title }: AuthModalProps) {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const { signIn, signUp } = useAuth();
  const { showToast } = useToast();

  useEffect(() => {
    if (open) {
      setError(null);
      setBusy(false);
    }
  }, [open]);

  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
      return () => { document.body.style.overflow = ''; };
    }
  }, [open]);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setBusy(true);

    const fn = mode === 'signin' ? signIn : signUp;
    const { error } = await fn(email, password);

    if (error) {
      setError(error);
      setBusy(false);
      return;
    }

    showToast(mode === 'signin' ? 'Welcome back!' : 'Account created!', 'success');
    setBusy(false);
    setEmail('');
    setPassword('');
    onClose();
    onSuccess?.();
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm backdrop-fade" onClick={onClose} />

      <div className="relative w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl shadow-2xl sheet-enter overflow-hidden">
        {/* Header */}
        <div className="gradient-teal-emerald px-6 pt-6 pb-8 text-white relative">
          <button
            onClick={onClose}
            className="absolute right-3 top-3 w-8 h-8 rounded-full bg-white/20 flex items-center justify-center btn-press"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2.5 mb-1">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
              <div className="relative">
                <MapPin className="w-5 h-5" fill="white" fillOpacity={0.2} strokeWidth={2.2} />
                <Home className="w-2 h-2 text-white absolute top-0.5 left-1/2 -translate-x-1/2" fill="white" />
              </div>
            </div>
          </div>
          <h2 className="text-xl font-bold">{title || (mode === 'signin' ? 'Sign In' : 'Create Account')}</h2>
          <p className="text-sm text-white/80 mt-0.5">
            {mode === 'signin' ? 'Access your listings' : 'Start listing your properties'}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Email</label>
            <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-3 border border-slate-200 dark:border-slate-700 focus-within:border-teal-400 transition-colors">
              <Mail className="w-4 h-4 text-slate-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@email.com"
                required
                className="flex-1 bg-transparent text-sm outline-none text-slate-800 dark:text-slate-100 placeholder:text-slate-400"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">Password</label>
            <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 rounded-xl px-3.5 py-3 border border-slate-200 dark:border-slate-700 focus-within:border-teal-400 transition-colors">
              <Lock className="w-4 h-4 text-slate-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min 6 characters"
                required
                minLength={6}
                className="flex-1 bg-transparent text-sm outline-none text-slate-800 dark:text-slate-100 placeholder:text-slate-400"
              />
            </div>
          </div>

          {error && (
            <div className="text-sm text-red-500 bg-red-50 dark:bg-red-950/30 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full py-3 rounded-xl gradient-teal-emerald text-white font-semibold text-sm btn-press shadow-md shadow-teal-500/20 disabled:opacity-50"
          >
            {busy ? 'Please wait...' : mode === 'signin' ? 'Sign In' : 'Create Account'}
          </button>

          <p className="text-center text-sm text-slate-500 dark:text-slate-400">
            {mode === 'signin' ? "Don't have an account? " : 'Already have an account? '}
            <button
              type="button"
              onClick={() => setMode(mode === 'signin' ? 'signup' : 'signin')}
              className="text-teal-600 dark:text-teal-400 font-semibold"
            >
              {mode === 'signin' ? 'Sign Up' : 'Sign In'}
            </button>
          </p>

          <p className="text-center text-xs text-slate-400 pt-1">
            🇮🇳 Made with ❤️ in India for Bharat
          </p>
        </form>
      </div>
    </div>
  );
}
