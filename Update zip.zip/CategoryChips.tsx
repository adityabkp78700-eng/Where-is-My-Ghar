import { Building2, BedDouble, House } from 'lucide-react';
import { PropertyCategory } from '@/lib/types';

interface CategoryChipsProps {
  selected: PropertyCategory | 'all';
  onSelect: (c: PropertyCategory | 'all') => void;
}

const CHIPS: { value: PropertyCategory | 'all'; label: string; icon: typeof Building2 }[] = [
  { value: 'all', label: 'All', icon: House },
  { value: 'hostel', label: 'Hostels', icon: Building2 },
  { value: 'room', label: 'Rental Rooms', icon: BedDouble },
  { value: 'flat', label: 'Flats', icon: House },
];

export default function CategoryChips({ selected, onSelect }: CategoryChipsProps) {
  return (
    <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-4 px-4 gpu-scroll">
      {CHIPS.map((chip) => {
        const Icon = chip.icon;
        return (
          <button
            key={chip.value}
            onClick={() => onSelect(chip.value)}
            className={`flex h-[52px] flex-shrink-0 items-center gap-2 rounded-full border px-4 text-[15px] font-semibold tracking-[-0.5px] nav-pill btn-press ${
              selected === chip.value
                ? 'border-teal-500 bg-teal-50 text-teal-600 shadow-[0_8px_18px_rgba(13,148,136,0.12)] dark:bg-teal-900/30 dark:text-teal-300'
                : 'border-slate-300 bg-white text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100'
            }`}
          >
            <Icon className="h-5 w-5" strokeWidth={2.2} />
            {chip.label}
          </button>
        );
      })}
    </div>
  );
}

export { CHIPS };