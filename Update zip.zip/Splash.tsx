import Logo from '@/components/Logo';

export default function Splash() {
  return (
    <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-gradient-to-br from-slate-50 via-teal-50 to-emerald-50 dark:from-slate-950 dark:via-slate-900 dark:to-teal-950">
      <div className="splash-logo flex flex-col items-center gap-4">
        <div className="relative">
          <div className="w-24 h-24 shadow-2xl shadow-teal-500/30">
            <Logo size={96} />
          </div>
        </div>
        <div className="text-center">
          <h1 className="text-2xl font-bold gradient-text">Where Is My Ghar</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Find your next rental home</p>
        </div>
      </div>

      <div className="absolute bottom-10 left-0 right-0 text-center">
        <p className="text-sm font-medium text-slate-600 dark:text-slate-400">
          🇮🇳 Made with ❤️ in India for Bharat
        </p>
      </div>
    </div>
  );
}
