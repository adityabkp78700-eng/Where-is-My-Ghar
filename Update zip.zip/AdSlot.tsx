import { SHOW_ADS } from '@/lib/types';

export default function AdSlot({ variant = 'feed' }: { variant?: 'feed' | 'detail' }) {
  if (!SHOW_ADS) return null;

  return (
    <div
      className={`rounded-2xl border border-dashed border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center text-slate-400 dark:text-slate-500 text-xs font-medium ${
        variant === 'feed' ? 'h-24' : 'h-20'
      }`}
    >
      Ad Slot — Inactive (SHOW_ADS = false)
    </div>
  );
}
