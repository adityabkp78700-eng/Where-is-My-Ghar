import { useState, useRef, useEffect } from 'react';
import { User, Sun, Moon, Monitor, Info, LogOut, LogIn, Building2 } from 'lucide-react';
import Logo from '@/components/Logo';
import { playClickSound } from '@/lib/sound';
import { useTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';
import type { ThemeMode, AppMode } from '@/lib/types';

interface HeaderProps {
  mode: AppMode;
  onSignIn?: () => void;
  onLogoClick?: () => void;
}

export default function Header({ mode, onSignIn, onLogoClick }: HeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { mode: themeMode, setMode } = useTheme();
  const { user, signOut } = useAuth();
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const themeOptions: { value: ThemeMode; label: string; icon: typeof Sun }[] = [
    { value: 'light', label: 'Light', icon: Sun },
    { value: 'dark', label: 'Dark', icon: Moon },
    { value: 'system', label: 'System', icon: Monitor },
  ];

  const modeLabel = mode === 'owner' ? 'Owner Pro Mode' : 'Guest Mode';

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/70 bg-white/90 backdrop-blur-xl dark:border-slate-800/70 dark:bg-slate-950/90 gpu-layer">
      <div className="mx-auto max-w-2xl px-4 py-3">
        <div className="flex h-11 items-center justify-between">
          <button
            onClick={() => {
              playClickSound();
              navigator.vibrate?.(25);
              onLogoClick?.();
            }}
            className="group flex items-center gap-2.5 rounded-xl transition-all duration-300 active:scale-95 focus:outline-none"
            aria-label="Reset to home feed"
          >
            <div className="h-10 w-10 shadow-md shadow-teal-500/20 transition-all duration-300 group-active:shadow-[0_0_20px_rgba(13,148,136,0.6)] group-active:scale-110">
              <Logo size={40} />
            </div>
            <div className="text-left">
              <h1 className="text-base font-bold leading-none gradient-text sm:text-lg">Where Is My Ghar</h1>
              <span className="mt-1 inline-block rounded-full bg-emerald-50 px-2 py-0.5 text-[9px] font-bold text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-400">
                Direct Owner · Zero Brokerage
              </span>
            </div>
          </button>

          <div className="relative" ref={menuRef}>
            <button
              onClick={() => setMenuOpen((open) => !open)}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 transition-colors hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 btn-press"
              aria-label="Open profile menu"
            >
              {mode === 'owner' && user ? (
                <Building2 className="h-5 w-5 text-teal-600 dark:text-teal-400" />
              ) : (
                <User className="h-5 w-5 text-slate-600 dark:text-slate-300" />
              )}
            </button>

            {menuOpen && (
              <div className="absolute right-0 top-12 w-64 origin-top-right overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl sheet-enter dark:border-slate-700 dark:bg-slate-800">
                <div className="border-b border-slate-100 px-4 py-3 dark:border-slate-700">
                  {mode === 'owner' && user ? (
                    <>
                      <p className="text-sm font-semibold text-teal-600 dark:text-teal-400">{modeLabel}</p>
                      <p className="truncate text-xs text-slate-500 dark:text-slate-400">{user.email}</p>
                    </>
                  ) : mode === 'owner' ? (
                    <>
                      <p className="text-sm font-semibold text-teal-600 dark:text-teal-400">{modeLabel}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Sign in to manage listings</p>
                    </>
                  ) : (
                    <>
                      <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{modeLabel}</p>
                      {user ? (
                        <p className="truncate text-xs text-slate-500 dark:text-slate-400">{user.email}</p>
                      ) : (
                        <p className="text-xs text-slate-500 dark:text-slate-400">Browse without an account</p>
                      )}
                    </>
                  )}
                </div>

                {!user && onSignIn && (
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onSignIn();
                    }}
                    className="flex w-full items-center gap-2 border-b border-slate-100 px-4 py-3 text-teal-600 transition-colors hover:bg-teal-50 dark:border-slate-700 dark:text-teal-400 dark:hover:bg-teal-950/30"
                  >
                    <LogIn className="h-4 w-4" />
                    <span className="text-sm font-semibold">Sign In / Sign Up</span>
                  </button>
                )}

                <div className="border-b border-slate-100 px-4 py-3 dark:border-slate-700">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Theme</p>
                  <div className="flex gap-1.5">
                    {themeOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => setMode(option.value)}
                        className={`flex flex-1 flex-col items-center gap-1 rounded-lg py-2 text-xs font-medium transition-all ${themeMode === option.value ? 'bg-teal-50 text-teal-600 dark:bg-teal-900/30 dark:text-teal-400' : 'text-slate-500 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-700/50'}`}
                      >
                        <option.icon className="h-4 w-4" />{option.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="border-b border-slate-100 px-4 py-3 dark:border-slate-700">
                  <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300"><Info className="h-4 w-4" /><span className="text-sm font-medium">About App</span></div>
                  <p className="mt-1.5 text-center text-xs font-medium text-slate-500 dark:text-slate-400">Made with love in India for Bharat</p>
                </div>
                {user && <button onClick={() => { signOut(); setMenuOpen(false); }} className="flex w-full items-center gap-2 px-4 py-3 text-red-500 transition-colors hover:bg-red-50 dark:hover:bg-red-950/30"><LogOut className="h-4 w-4" /><span className="text-sm font-medium">Sign Out</span></button>}
              </div>
            )}
          </div>
        </div>

      </div>
    </header>
  );
}
