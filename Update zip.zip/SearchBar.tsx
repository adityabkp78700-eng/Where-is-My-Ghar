import { Search, Mic, X, Loader2 } from 'lucide-react';
import { useRef, useEffect, useState } from 'react';
import { useToast } from '@/context/ToastContext';

interface SearchBarProps {
  value: string;
  onChange: (v: string) => void;
  onVoiceResult: (v: string) => void;
}

export default function SearchBar({ value, onChange, onVoiceResult }: SearchBarProps) {
  const recognitionRef = useRef<any>(null);
  const isListeningRef = useRef(false);
  const [isListening, setIsListening] = useState(false);
  const { showToast } = useToast();

  const startVoice = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showToast('Voice search not supported on this browser. Please type.', 'error');
      return;
    }

    if (isListeningRef.current) {
      recognitionRef.current?.stop();
      isListeningRef.current = false;
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    recognition.continuous = false;
    recognition.interimResults = false;
    recognitionRef.current = recognition;
    isListeningRef.current = true;
    setIsListening(true);

    recognition.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      onVoiceResult(transcript);
      isListeningRef.current = false;
      setIsListening(false);
      showToast(`Heard: "${transcript}"`, 'success');
    };
    recognition.onerror = (e: any) => {
      isListeningRef.current = false;
      setIsListening(false);
      if (e?.error === 'not-allowed' || e?.error === 'service-not-allowed') {
        showToast('Microphone permission denied. Please allow mic access.', 'error');
      } else if (e?.error === 'no-speech') {
        showToast('No speech detected. Please try again.', 'error');
      } else {
        showToast('Voice search error. Please try again.', 'error');
      }
    };
    recognition.onend = () => {
      isListeningRef.current = false;
      setIsListening(false);
    };
    recognition.start();
  };

  useEffect(() => {
    return () => {
      recognitionRef.current?.stop();
    };
  }, []);

  return (
    <div className="relative">
      <div className="flex min-h-[60px] items-center gap-3 rounded-full border border-white/70 bg-white px-5 py-2.5 shadow-[0_8px_24px_rgba(0,0,0,0.08)] dark:bg-slate-800 focus-within:border-teal-400 dark:focus-within:border-teal-600 transition-colors">
        <Search className="h-6 w-6 flex-shrink-0 text-slate-500" strokeWidth={2.4} />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={isListening ? 'Listening... speak now' : 'Search by city, locality, landmark or pincode'}
          className="min-w-0 flex-1 bg-transparent text-[15px] font-normal text-slate-700 outline-none placeholder:text-slate-400 dark:text-slate-100"
        />
        {value && !isListening && (
          <button onClick={() => onChange('')} className="flex-shrink-0 btn-press">
            <X className="w-4 h-4 text-slate-400" />
          </button>
        )}
        <button
          onClick={startVoice}
          className={`relative flex h-7 w-7 flex-shrink-0 rounded-full items-center justify-center btn-press transition-all ${
            isListening
              ? 'bg-red-500 text-white'
              : 'bg-teal-50 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400 hover:bg-teal-100 dark:hover:bg-teal-900/50'
          }`}
          aria-label={isListening ? 'Stop voice search' : 'Voice search'}
        >
          {isListening ? (
            <>
              <span className="absolute inset-0 rounded-full bg-red-400 animate-ping opacity-60" />
              <Mic className="w-4 h-4 relative z-10" />
            </>
          ) : (
            <Mic className="w-4 h-4" />
          )}
        </button>
      </div>
    </div>
  );
}
