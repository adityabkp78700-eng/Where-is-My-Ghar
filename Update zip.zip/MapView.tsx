import { MapPin, Navigation, Building2 } from 'lucide-react';
import type { Property } from '@/lib/types';
import { CATEGORY_LABELS, formatRent } from '@/lib/types';

interface MapViewProps {
  properties: Property[];
  onSelect: (p: Property) => void;
}

export default function MapView({ properties, onSelect }: MapViewProps) {
  const hasCoords = properties.filter((p) => p.latitude != null && p.longitude != null);

  if (hasCoords.length === 0) {
    return (
      <div className="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-8 text-center">
        <MapPin className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
        <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">No GPS coordinates available</p>
        <p className="text-xs text-slate-400 mt-1">None of these listings have GPS location data for map display.</p>
      </div>
    );
  }

  // Compute bounding box
  const lats = hasCoords.map((p) => p.latitude!);
  const lngs = hasCoords.map((p) => p.longitude!);
  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  const minLng = Math.min(...lngs);
  const maxLng = Math.max(...lngs);
  const centerLat = (minLat + maxLat) / 2;
  const centerLng = (minLng + maxLng) / 2;
  const spanLat = Math.max(maxLat - minLat, 0.01);
  const spanLng = Math.max(maxLng - minLng, 0.01);
  const zoom = Math.min(15, Math.max(10, Math.floor(8 - Math.log2(Math.max(spanLat, spanLng)))));

  const mapEmbedUrl = `https://www.google.com/maps?q=${centerLat},${centerLng}&z=${zoom}&output=embed`;

  return (
    <div className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
      <div className="relative h-[400px] bg-slate-100 dark:bg-slate-700">
        <iframe
          src={mapEmbedUrl}
          className="w-full h-full"
          style={{ border: 0 }}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="Properties map view"
        />

        {/* Property pins overlay list */}
        <div className="absolute bottom-0 left-0 right-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur max-h-[180px] overflow-y-auto gpu-scroll no-scrollbar border-t border-slate-200 dark:border-slate-700">
          <div className="p-2 space-y-1.5">
            {hasCoords.map((p) => (
              <button
                key={p.id}
                onClick={() => onSelect(p)}
                className="w-full flex items-center gap-2.5 rounded-xl p-2 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left btn-press"
              >
                <div className="w-10 h-10 rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-700 flex-shrink-0">
                  {p.photo_urls[0] ? (
                    <img src={p.photo_urls[0]} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Building2 className="w-5 h-5 text-slate-300 dark:text-slate-600" />
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-bold text-slate-900 dark:text-white">{formatRent(p.monthly_rent)}/mo</span>
                    <span className="text-[10px] font-semibold text-teal-600 dark:text-teal-400">{CATEGORY_LABELS[p.category]}</span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {p.city}, {p.state}
                  </p>
                </div>
                <Navigation className="w-4 h-4 text-slate-300 dark:text-slate-600 flex-shrink-0" />
              </button>
            ))}
          </div>
        </div>
      </div>
      <div className="px-3 py-2 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-700">
        <p className="text-xs text-slate-400 flex items-center gap-1.5">
          <MapPin className="w-3 h-3" />
          {hasCoords.length} of {properties.length} properties have GPS location
        </p>
      </div>
    </div>
  );
}
