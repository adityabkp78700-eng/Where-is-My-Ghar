/*
# Fix property_reports schema and function search_path

## Purpose
1. Add missing `reporter_email` column to `property_reports` table (the ReportModal inserts this field but the column doesn't exist yet).
2. Fix the `update_updated_at_column` function to have an immutable search_path (Supabase security advisor warning).

## Changes
- `property_reports`: ADD COLUMN `reporter_email` text (nullable) — stores optional contact email for the person reporting.
- `update_updated_at_column`: recreated with `SET search_path = public` to satisfy the security linter.

## Security
- No policy changes. The existing `public_insert_report` INSERT policy (anon + authenticated, WITH CHECK true) allows anyone to submit reports.
*/

ALTER TABLE property_reports
  ADD COLUMN IF NOT EXISTS reporter_email text;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  NEW.last_activity_at = now();
  RETURN NEW;
END;
$$;
